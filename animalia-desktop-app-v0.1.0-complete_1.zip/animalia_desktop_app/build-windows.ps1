# Animalia Desktop App - Windows Build Script
# Este script compila la aplicación para Windows

Write-Host "╔════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║   Animalia Desktop App - Compilación para Windows         ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Green

# Verificar si Node.js está instalado
Write-Host "`n[1/5] Verificando Node.js..." -ForegroundColor Cyan
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: Node.js no está instalado. Descárgalo desde https://nodejs.org/" -ForegroundColor Red
    exit 1
}
Write-Host "✓ Node.js encontrado: $(node --version)" -ForegroundColor Green

# Verificar si Rust está instalado
Write-Host "`n[2/5] Verificando Rust..." -ForegroundColor Cyan
if (-not (Get-Command rustc -ErrorAction SilentlyContinue)) {
    Write-Host "ERROR: Rust no está instalado." -ForegroundColor Red
    Write-Host "Descárgalo desde https://rustup.rs/" -ForegroundColor Yellow
    exit 1
}
Write-Host "✓ Rust encontrado: $(rustc --version)" -ForegroundColor Green

# Instalar dependencias
Write-Host "`n[3/5] Instalando dependencias..." -ForegroundColor Cyan
npm install
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Fallo al instalar dependencias" -ForegroundColor Red
    exit 1
}
Write-Host "✓ Dependencias instaladas" -ForegroundColor Green

# Compilar la aplicación
Write-Host "`n[4/5] Compilando aplicación..." -ForegroundColor Cyan
npm run build
if ($LASTEXITCODE -ne 0) {
    Write-Host "ERROR: Fallo al compilar" -ForegroundColor Red
    exit 1
}
Write-Host "✓ Compilación completada" -ForegroundColor Green

# Generar instalador
Write-Host "`n[5/5] Generando instalador .msi..." -ForegroundColor Cyan
Write-Host "El instalador se generará en: src-tauri/target/release/bundle/msi/" -ForegroundColor Yellow

Write-Host "`n╔════════════════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║   ✓ Compilación completada exitosamente                   ║" -ForegroundColor Green
Write-Host "║   El instalador .msi está listo para descargar            ║" -ForegroundColor Green
Write-Host "╚════════════════════════════════════════════════════════════╝" -ForegroundColor Green

Write-Host "`nPasos siguientes:" -ForegroundColor Cyan
Write-Host "1. Busca el archivo .msi en: src-tauri/target/release/bundle/msi/" -ForegroundColor White
Write-Host "2. Haz doble clic para instalar" -ForegroundColor White
Write-Host "3. Sigue el asistente de instalación" -ForegroundColor White
