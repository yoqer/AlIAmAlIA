import type { AnimalSpecies } from '../types'

export const ANIMAL_HIERARCHY: Record<string, AnimalSpecies[]> = {
  mammals: [
    {
      id: 'canis-lupus-familiaris',
      scientificName: 'Canis lupus familiaris',
      commonName: 'Perro',
      kingdom: 'Animalia',
      phylum: 'Chordata',
      class: 'Mammalia',
      order: 'Carnivora',
      family: 'Canidae',
      genus: 'Canis',
      species: 'lupus familiaris',
    },
    {
      id: 'felis-catus',
      scientificName: 'Felis catus',
      commonName: 'Gato',
      kingdom: 'Animalia',
      phylum: 'Chordata',
      class: 'Mammalia',
      order: 'Carnivora',
      family: 'Felidae',
      genus: 'Felis',
      species: 'catus',
    },
    {
      id: 'equus-ferus-caballus',
      scientificName: 'Equus ferus caballus',
      commonName: 'Caballo',
      kingdom: 'Animalia',
      phylum: 'Chordata',
      class: 'Mammalia',
      order: 'Perissodactyla',
      family: 'Equidae',
      genus: 'Equus',
      species: 'ferus caballus',
    },
  ],
  birds: [
    {
      id: 'columba-livia',
      scientificName: 'Columba livia',
      commonName: 'Paloma',
      kingdom: 'Animalia',
      phylum: 'Chordata',
      class: 'Aves',
      order: 'Columbiformes',
      family: 'Columbidae',
      genus: 'Columba',
      species: 'livia',
    },
    {
      id: 'aquila-chrysaetos',
      scientificName: 'Aquila chrysaetos',
      commonName: 'Águila Real',
      kingdom: 'Animalia',
      phylum: 'Chordata',
      class: 'Aves',
      order: 'Accipitriformes',
      family: 'Accipitridae',
      genus: 'Aquila',
      species: 'chrysaetos',
    },
  ],
  reptiles: [
    {
      id: 'python-regius',
      scientificName: 'Python regius',
      commonName: 'Serpiente Real',
      kingdom: 'Animalia',
      phylum: 'Chordata',
      class: 'Reptilia',
      order: 'Squamata',
      family: 'Pythonidae',
      genus: 'Python',
      species: 'regius',
    },
  ],
  amphibians: [
    {
      id: 'rana-temporaria',
      scientificName: 'Rana temporaria',
      commonName: 'Rana Común',
      kingdom: 'Animalia',
      phylum: 'Chordata',
      class: 'Amphibia',
      order: 'Anura',
      family: 'Ranidae',
      genus: 'Rana',
      species: 'temporaria',
    },
  ],
  fish: [
    {
      id: 'danio-rerio',
      scientificName: 'Danio rerio',
      commonName: 'Pez Cebra',
      kingdom: 'Animalia',
      phylum: 'Chordata',
      class: 'Actinopterygii',
      order: 'Cypriniformes',
      family: 'Cyprinidae',
      genus: 'Danio',
      species: 'rerio',
    },
  ],
}

export function getAllSpecies(): AnimalSpecies[] {
  return Object.values(ANIMAL_HIERARCHY).flat()
}

export function getSpeciesByClass(className: string): AnimalSpecies[] {
  return Object.entries(ANIMAL_HIERARCHY)
    .filter(([, species]) => species.some((s) => s.class === className))
    .flatMap(([, species]) => species)
}

export function getSpeciesById(id: string): AnimalSpecies | undefined {
  return getAllSpecies().find((s) => s.id === id)
}

export function searchSpecies(query: string): AnimalSpecies[] {
  const lowerQuery = query.toLowerCase()
  return getAllSpecies().filter(
    (s) =>
      s.commonName.toLowerCase().includes(lowerQuery) ||
      s.scientificName.toLowerCase().includes(lowerQuery)
  )
}

export function getHierarchyCategories(): string[] {
  return Object.keys(ANIMAL_HIERARCHY)
}
