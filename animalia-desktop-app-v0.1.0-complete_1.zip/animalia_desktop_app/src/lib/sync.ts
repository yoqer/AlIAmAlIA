import axios from 'axios'
import type { AppConfig } from '../types'

const HOSTING_BASE_URL = 'https://torete.net/animaliav3'

export async function initializeSync(config: AppConfig) {
  try {
    const response = await axios.get(`${HOSTING_BASE_URL}/api/init`, {
      params: {
        userId: config.userId,
      },
    })
    return response.data
  } catch (error) {
    console.error('Failed to initialize sync:', error)
    throw error
  }
}

export async function fetchUserData(userId: string) {
  try {
    const response = await axios.get(`${HOSTING_BASE_URL}/api/user/${userId}`)
    return response.data
  } catch (error) {
    console.error('Failed to fetch user data:', error)
    throw error
  }
}

export async function fetchBehaviorPatterns(userId: string) {
  try {
    const response = await axios.get(`${HOSTING_BASE_URL}/api/patterns/${userId}`)
    return response.data
  } catch (error) {
    console.error('Failed to fetch behavior patterns:', error)
    throw error
  }
}

export async function fetchAnimalSpecies(userId: string) {
  try {
    const response = await axios.get(`${HOSTING_BASE_URL}/api/species/${userId}`)
    return response.data
  } catch (error) {
    console.error('Failed to fetch animal species:', error)
    throw error
  }
}

export async function syncConversations(userId: string, conversations: any[]) {
  try {
    const response = await axios.post(`${HOSTING_BASE_URL}/api/conversations/sync`, {
      userId,
      conversations,
    })
    return response.data
  } catch (error) {
    console.error('Failed to sync conversations:', error)
    throw error
  }
}

export async function requestRetraining(userId: string, requestData: any) {
  try {
    const response = await axios.post(`${HOSTING_BASE_URL}/api/retraining/request`, {
      userId,
      ...requestData,
    })
    return response.data
  } catch (error) {
    console.error('Failed to request retraining:', error)
    throw error
  }
}

export async function exportData(userId: string, format: 'json' | 'sqlite') {
  try {
    const response = await axios.get(`${HOSTING_BASE_URL}/api/export`, {
      params: {
        userId,
        format,
      },
      responseType: format === 'json' ? 'json' : 'blob',
    })
    return response.data
  } catch (error) {
    console.error('Failed to export data:', error)
    throw error
  }
}

export async function importData(userId: string, data: any, format: 'json' | 'sqlite') {
  try {
    const formData = new FormData()
    formData.append('userId', userId)
    formData.append('format', format)
    if (format === 'json') {
      formData.append('data', JSON.stringify(data))
    } else {
      formData.append('data', data)
    }

    const response = await axios.post(`${HOSTING_BASE_URL}/api/import`, formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
    return response.data
  } catch (error) {
    console.error('Failed to import data:', error)
    throw error
  }
}
