import React from 'react'
import { useAppStore } from './stores/appStore'
import TabBar from './components/TabBar'
import ChatPage from './pages/ChatPage'
import PatternsPage from './pages/PatternsPage'
import KnowledgePage from './pages/KnowledgePage'
import RetrainingPage from './pages/RetrainingPage'
import SettingsPage from './pages/SettingsPage'

export default function App() {
  const { selectedTab } = useAppStore()

  const renderPage = () => {
    switch (selectedTab) {
      case 'chat':
        return <ChatPage />
      case 'patterns':
        return <PatternsPage />
      case 'knowledge':
        return <KnowledgePage />
      case 'retraining':
        return <RetrainingPage />
      case 'settings':
        return <SettingsPage />
      default:
        return <ChatPage />
    }
  }

  return (
    <div className="flex flex-col h-screen bg-white">
      <div className="flex-1 overflow-hidden">
        {renderPage()}
      </div>
      <TabBar />
    </div>
  )
}
