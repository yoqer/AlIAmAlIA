import { useEffect, useState } from 'react'
import { useAppStore } from '../stores/appStore'
import * as syncService from '../lib/sync'
import type { AppConfig } from '../types'

export function useSyncManager(config: AppConfig | null) {
  const { updateSyncStatus } = useAppStore()
  const [isSyncing, setIsSyncing] = useState(false)
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null)

  useEffect(() => {
    if (!config || !config.syncPreferences.autoSync) return

    const syncInterval = setInterval(async () => {
      await performSync(config)
    }, config.syncPreferences.syncInterval * 1000)

    return () => clearInterval(syncInterval)
  }, [config])

  useEffect(() => {
    if (!config || !config.syncPreferences.syncOnStartup) return

    performSync(config).catch((error) => {
      console.error('Initial sync failed:', error)
    })
  }, [config?.userId])

  async function performSync(cfg: AppConfig) {
    if (isSyncing) return

    setIsSyncing(true)
    updateSyncStatus({
      isSyncing: true,
      syncErrors: [],
    })

    try {
      await syncService.initializeSync(cfg)
      await syncService.fetchUserData(cfg.userId)
      await syncService.fetchBehaviorPatterns(cfg.userId)
      await syncService.fetchAnimalSpecies(cfg.userId)

      updateSyncStatus({
        lastSync: new Date(),
        isSyncing: false,
        pendingChanges: 0,
        syncErrors: [],
      })

      setLastSyncTime(new Date())
      console.log('Sync completed successfully')
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error'
      console.error('Sync error:', errorMessage)

      updateSyncStatus({
        isSyncing: false,
        syncErrors: [errorMessage],
      })
    } finally {
      setIsSyncing(false)
    }
  }

  return {
    isSyncing,
    lastSyncTime,
    performSync,
  }
}
