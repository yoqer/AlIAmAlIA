import React, { useState } from 'react'
import { Plus, Upload, Trash2 } from 'lucide-react'

interface KnowledgeItem {
  id: string
  type: 'behavior' | 'communication' | 'training_data'
  title: string
  content: string
  source: 'manual' | 'imported' | 'synced'
  createdAt: Date
}

export default function KnowledgePage() {
  const [knowledge, setKnowledge] = useState<KnowledgeItem[]>([])
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    type: 'behavior' as const,
    title: '',
    content: '',
  })

  const handleAddKnowledge = () => {
    if (!formData.title.trim() || !formData.content.trim()) return

    const newItem: KnowledgeItem = {
      id: Date.now().toString(),
      type: formData.type,
      title: formData.title,
      content: formData.content,
      source: 'manual',
      createdAt: new Date(),
    }

    setKnowledge([...knowledge, newItem])
    setFormData({ type: 'behavior', title: '', content: '' })
    setShowForm(false)
  }

  const handleDeleteKnowledge = (id: string) => {
    setKnowledge(knowledge.filter((item) => item.id !== id))
  }

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-lg font-semibold text-gray-900">Gestión de Conocimiento</h1>
          <button
            onClick={() => setShowForm(!showForm)}
            className="p-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            aria-label="Agregar conocimiento"
          >
            <Plus size={20} />
          </button>
        </div>

        <label className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
          <Upload size={18} className="text-gray-600" />
          <span className="text-sm text-gray-700">Importar JSON</span>
          <input
            type="file"
            accept=".json"
            className="hidden"
          />
        </label>
      </div>

      {showForm && (
        <div className="p-4 border-b border-gray-200 bg-gray-50">
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tipo</label>
              <select
                value={formData.type}
                onChange={(e) =>
                  setFormData({ ...formData, type: e.target.value as any })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="behavior">Comportamiento</option>
                <option value="communication">Comunicación</option>
                <option value="training_data">Datos de Entrenamiento</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Título</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Título del conocimiento"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Contenido</label>
              <textarea
                value={formData.content}
                onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                placeholder="Describe el conocimiento..."
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 resize-none"
              />
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleAddKnowledge}
                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Guardar
              </button>
              <button
                onClick={() => setShowForm(false)}
                className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4 space-y-3 safe-pb-20">
        {knowledge.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-500">
            <p className="text-center">No hay conocimiento registrado</p>
          </div>
        ) : (
          knowledge.map((item) => (
            <div
              key={item.id}
              className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h3 className="font-semibold text-gray-900">{item.title}</h3>
                  <p className="text-xs text-gray-500 mt-1">
                    {item.type} • {item.source}
                  </p>
                </div>
                <button
                  onClick={() => handleDeleteKnowledge(item.id)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors"
                  aria-label="Eliminar"
                >
                  <Trash2 size={18} />
                </button>
              </div>
              <p className="text-sm text-gray-600 line-clamp-3">{item.content}</p>
              <p className="text-xs text-gray-400 mt-2">
                {item.createdAt.toLocaleDateString()}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
