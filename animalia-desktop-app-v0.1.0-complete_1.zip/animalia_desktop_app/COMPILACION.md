# Guía de Compilación - Animalia Desktop App

Esta guía proporciona instrucciones detalladas para compilar Animalia Desktop App para todas las plataformas.

## 📋 Estructura de Compilación

```
animalia-desktop-app/
├── build-windows.ps1      # Script de compilación para Windows
├── build-macos.sh         # Script de compilación para macOS
├── build-linux.sh         # Script de compilación para Linux
├── build-android.sh       # Script de compilación para Android
├── build-ios.sh           # Script de compilación para iOS
├── tauri.conf.json        # Configuración general
├── tauri.conf.windows.json # Configuración específica Windows
├── tauri.conf.macos.json  # Configuración específica macOS
├── tauri.conf.linux.json  # Configuración específica Linux
├── tauri.conf.android.json # Configuración específica Android
└── tauri.conf.ios.json    # Configuración específica iOS
```

## 🔨 Compilación Rápida

### Opción 1: Usar Scripts Automatizados (Recomendado)

#### Windows
```powershell
.\build-windows.ps1
```

#### macOS
```bash
chmod +x build-macos.sh
./build-macos.sh
```

#### Linux
```bash
chmod +x build-linux.sh
./build-linux.sh
```

#### Android
```bash
chmod +x build-android.sh
./build-android.sh
```

#### iOS (solo macOS)
```bash
chmod +x build-ios.sh
./build-ios.sh
```

### Opción 2: Compilación Manual

#### 1. Instalar Dependencias
```bash
npm install
```

#### 2. Compilar para una Plataforma Específica

**Windows:**
```bash
npm run build -- --target x86_64-pc-windows-msvc
```

**macOS (Intel):**
```bash
npm run build -- --target x86_64-apple-darwin
```

**macOS (Apple Silicon):**
```bash
npm run build -- --target aarch64-apple-darwin
```

**Linux:**
```bash
npm run build -- --target x86_64-unknown-linux-gnu
```

**Android:**
```bash
npm run build -- --target aarch64-linux-android
```

**iOS:**
```bash
npm run build -- --target aarch64-apple-ios
```

## 📦 Ubicación de Archivos Compilados

Después de compilar, los archivos se encuentran en:

### Windows
- **Instalador MSI**: `src-tauri/target/release/bundle/msi/`
- **Instalador NSIS**: `src-tauri/target/release/bundle/nsis/`

### macOS
- **Paquete DMG**: `src-tauri/target/release/bundle/dmg/`
- **Aplicación APP**: `src-tauri/target/release/bundle/macos/`

### Linux
- **AppImage**: `src-tauri/target/release/bundle/appimage/`
- **Paquete DEB**: `src-tauri/target/release/bundle/deb/`

### Android
- **APK**: `src-tauri/target/release/bundle/apk/`

### iOS
- **IPA**: `src-tauri/target/release/bundle/ios/`

## 🎯 Compilación Optimizada

### Reducir Tamaño de Compilación

```bash
# Eliminar símbolos de depuración
cargo build --release

# Usar strip para reducir tamaño
strip target/release/animalia_desktop_app
```

### Compilación Paralela

```bash
# Usar múltiples núcleos de CPU
cargo build -j $(nproc)
```

### Caché de Compilación

```bash
# Limpiar caché
cargo clean

# Reconstruir desde cero
npm run build
```

## 🔐 Firma de Aplicaciones

### Windows (Opcional)

Para firmar el instalador MSI:

```powershell
# Necesitas un certificado de firma de código
signtool sign /f "tu_certificado.pfx" /p "contraseña" /t "http://timestamp.server" "archivo.msi"
```

### macOS (Requerido para distribución)

```bash
# Firmar la aplicación
codesign -s "Developer ID Application" -v dist/Animalia_Desktop_App.app

# Notarizar (para macOS 10.15+)
xcrun altool --notarize-app -f dist/Animalia_Desktop_App.dmg -t osx -u "email@apple.com" -p "contraseña"
```

### iOS (Requerido)

La firma se realiza automáticamente a través de Xcode o App Store Connect.

## 🧪 Pruebas Antes de Compilar

### Verificar Configuración

```bash
# Verificar tipos TypeScript
npm run check

# Ejecutar linter
npm run lint

# Ejecutar tests
npm run test
```

### Prueba en Desarrollo

```bash
# Ejecutar en modo desarrollo
npm run dev

# Abre http://localhost:5173 en tu navegador
```

## 📊 Información de Compilación

### Versiones de Herramientas Recomendadas

| Herramienta | Versión Mínima | Versión Recomendada |
|------------|----------------|-------------------|
| Node.js | 18.0.0 | 22.0.0+ |
| npm | 9.0.0 | 10.0.0+ |
| Rust | 1.70.0 | 1.75.0+ |
| Tauri | 2.0.0 | 2.0.0+ |

### Tiempo de Compilación Estimado

| Plataforma | Primera Vez | Subsecuentes |
|-----------|-----------|------------|
| Windows | 10-15 min | 2-5 min |
| macOS | 12-18 min | 3-7 min |
| Linux | 10-15 min | 2-5 min |
| Android | 15-20 min | 5-10 min |
| iOS | 15-20 min | 5-10 min |

### Tamaño de Compilación Estimado

| Plataforma | Tamaño |
|-----------|--------|
| Windows (MSI) | 60-80 MB |
| macOS (DMG) | 70-90 MB |
| Linux (AppImage) | 50-70 MB |
| Linux (DEB) | 40-60 MB |
| Android (APK) | 50-70 MB |
| iOS (IPA) | 60-80 MB |

## 🐛 Solución de Problemas

### Error: "Rust no encontrado"

```bash
# Instalar Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Agregar a PATH
source $HOME/.cargo/env
```

### Error: "Node.js versión incompatible"

```bash
# Actualizar Node.js
nvm install 22
nvm use 22
```

### Error: "Fallo al compilar Tauri"

```bash
# Limpiar y reconstruir
cargo clean
npm install
npm run build
```

### Error: "Dependencias del sistema faltantes" (Linux)

```bash
# Ubuntu/Debian
sudo apt-get install -y \
  build-essential \
  libssl-dev \
  pkg-config \
  libgtk-3-dev \
  libwebkit2gtk-4.0-dev

# Fedora/RHEL
sudo dnf install -y \
  gcc \
  openssl-devel \
  pkg-config \
  gtk3-devel \
  webkit2gtk3-devel
```

### Error: "Android SDK no configurado"

```bash
# Configurar ANDROID_SDK_ROOT
export ANDROID_SDK_ROOT=$HOME/Android/Sdk

# O en Windows (PowerShell)
$env:ANDROID_SDK_ROOT = "$env:USERPROFILE\AppData\Local\Android\Sdk"
```

## 🚀 Distribución

### Crear Paquete de Distribución

```bash
# Crear carpeta de distribución
mkdir -p dist/release

# Copiar instaladores
cp -r src-tauri/target/release/bundle/* dist/release/

# Crear ZIP
zip -r animalia-desktop-app-v0.1.0.zip dist/release/
```

### Subir a GitHub Releases

```bash
# Instalar GitHub CLI
# https://cli.github.com/

# Crear release
gh release create v0.1.0 \
  dist/release/animalia-desktop-app-v0.1.0.zip \
  --title "Animalia Desktop App v0.1.0" \
  --notes "Primera versión de Animalia Desktop App"
```

## 📝 Notas Importantes

1. **Primera Compilación**: Toma más tiempo porque descarga todas las dependencias
2. **Caché**: Rust cachea compilaciones intermedias, compilaciones posteriores son más rápidas
3. **Espacio en Disco**: Asegúrate de tener al menos 5 GB libres
4. **Conexión a Internet**: Necesaria para descargar dependencias
5. **Permisos**: En Linux/macOS, asegúrate de tener permisos de ejecución

## 🔗 Enlaces Útiles

- [Documentación de Tauri](https://tauri.app/docs/)
- [Documentación de Rust](https://doc.rust-lang.org/)
- [Documentación de Node.js](https://nodejs.org/docs/)
- [Documentación de Android Studio](https://developer.android.com/studio/docs)
- [Documentación de Xcode](https://developer.apple.com/xcode/)
