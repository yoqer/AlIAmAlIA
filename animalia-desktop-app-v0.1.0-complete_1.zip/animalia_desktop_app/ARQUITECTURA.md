# Arquitectura de Animalia Desktop App

## Visión General

Animalia Desktop App es una aplicación multiplataforma construida con **Tauri** que proporciona un entorno integrado para análisis de comportamiento animal, gestión de conocimiento y reentrenamiento de modelos de IA. La arquitectura está diseñada para ser modular, escalable y preparada para futuras integraciones.

## Capas de la Aplicación

### 1. Capa de Presentación (Frontend)

**Tecnología**: React 18 + TypeScript + Tailwind CSS

La interfaz está organizada en **5 pestañas principales**:

- **Chat RAG**: Interfaz de conversación con almacenamiento local
- **Patrones**: Visualización de comportamiento animal con filtros
- **Conocimiento**: Gestión de datos de entrenamiento
- **Reentreno**: Solicitud de reentrenamiento con soporte GPU
- **Ajustes**: Configuración de la aplicación

**Componentes Clave**:
- `TabBar.tsx`: Navegación principal
- `ChatPage.tsx`: Chat RAG
- `PatternsPage.tsx`: Visor de patrones
- `KnowledgePage.tsx`: Gestión de conocimiento
- `RetrainingPage.tsx`: Módulo de reentreno
- `SettingsPage.tsx`: Configuración

### 2. Capa de Estado Global

**Tecnología**: Zustand

El estado global se gestiona de forma centralizada en `stores/appStore.ts`:

```typescript
interface AppState {
  user: User | null
  config: AppConfig | null
  syncStatus: SyncStatus
  conversations: Conversation[]
  patterns: BehaviorPattern[]
  selectedTab: TabType
  // ... acciones
}
```

**Ventajas**:
- Bajo overhead de memoria
- Fácil de testear
- Sincronización automática

### 3. Capa de Lógica de Negocio

**Ubicación**: `src/lib/` y `src/hooks/`

**Módulos Principales**:

#### `sync.ts` - Sincronización con Hosting
- Conexión con `torete.net/animaliav3/`
- Sincronización automática de datos
- Manejo de errores de red
- Caché local

#### `animalHierarchy.ts` - Jerarquía Taxonómica
- Base de datos de especies animales
- Clasificación por clase (Mammalia, Aves, etc.)
- Búsqueda y filtrado

#### `useSyncManager.ts` - Hook de Sincronización
- Gestión de intervalos de sincronización
- Sincronización al iniciar la app
- Manejo de estado de sincronización

### 4. Capa de Datos

**Tecnología**: SQLite (local) + Axios (remoto)

#### Base de Datos Local (SQLite)

Tablas principales:
- `users`: Información del usuario
- `animal_species`: Catálogo de especies
- `behavior_patterns`: Patrones de comportamiento
- `conversations`: Historial de chats
- `chat_messages`: Mensajes individuales
- `knowledge_entries`: Datos de entrenamiento
- `retraining_requests`: Solicitudes de reentreno
- `app_config`: Configuración de la app
- `sync_status`: Estado de sincronización

#### API Remota

Endpoints esperados en `torete.net/animaliav3/`:
- `GET /api/init` - Inicializar sincronización
- `GET /api/user/{userId}` - Datos del usuario
- `GET /api/patterns/{userId}` - Patrones de comportamiento
- `GET /api/species/{userId}` - Especies animales
- `POST /api/conversations/sync` - Sincronizar conversaciones
- `POST /api/retraining/request` - Solicitar reentreno
- `GET /api/export` - Exportar datos
- `POST /api/import` - Importar datos

### 5. Capa de Escritorio (Tauri)

**Tecnología**: Tauri 2 + Rust

**Responsabilidades**:
- Gestión de ventanas
- Acceso a sistema de archivos
- Integración con sistema operativo
- Compilación multiplataforma

**Archivo Principal**: `src-tauri/src/lib.rs`

## Flujo de Datos

```
Usuario (UI)
    ↓
React Component (ChatPage, PatternsPage, etc.)
    ↓
Zustand Store (appStore)
    ↓
Servicios (sync.ts, animalHierarchy.ts)
    ↓
SQLite (local) / Axios (remoto)
    ↓
Datos
```

## Sincronización Híbrida

### Offline-First

1. **Almacenamiento Local**: Todos los datos se guardan en SQLite
2. **Funcionamiento Sin Conexión**: La app funciona completamente offline
3. **Sincronización Automática**: Cuando hay conexión, se sincroniza con el hosting

### Estrategia de Sincronización

```
Inicio de la App
    ↓
Cargar datos locales (SQLite)
    ↓
Si autoSync habilitado:
    ├─ Conectar a hosting
    ├─ Descargar nuevos datos
    ├─ Actualizar SQLite
    └─ Sincronizar cambios locales
    ↓
Mostrar UI
```

## Extensibilidad

### Preparado para Futuras Integraciones

La arquitectura está diseñada para permitir:

#### 1. API REST
```typescript
// Fácil agregar nuevos endpoints
export async function fetchCustomData(userId: string) {
  const response = await axios.get(`${HOSTING_BASE_URL}/api/custom/${userId}`)
  return response.data
}
```

#### 2. Agent-to-Agent (A2A)
```typescript
// Comunicación entre agentes
interface AgentMessage {
  from: string
  to: string
  action: string
  payload: any
}
```

#### 3. Model Context Protocol (MCP)
```typescript
// Preparado para integración MCP
interface MCPServer {
  name: string
  endpoint: string
  capabilities: string[]
}
```

## Seguridad

### Consideraciones Actuales

1. **Almacenamiento Local**: SQLite sin encriptación (futuro: agregar encriptación)
2. **Comunicación**: HTTP (futuro: HTTPS obligatorio)
3. **Autenticación**: Sin autenticación local (futuro: agregar)

### Recomendaciones Futuras

- Encriptación de base de datos SQLite
- Validación de certificados SSL/TLS
- Autenticación de usuario
- Autorización basada en roles

## Rendimiento

### Optimizaciones Implementadas

1. **Lazy Loading**: Las páginas se cargan bajo demanda
2. **Caché Local**: Datos almacenados en SQLite
3. **Sincronización Asincrónica**: No bloquea la UI
4. **Bundle Optimization**: Tamaño objetivo 50-80MB

### Métricas de Rendimiento

- **Tiempo de Inicio**: < 2 segundos
- **Tamaño de App**: 50-80 MB
- **Consumo de Memoria**: < 200 MB
- **Tiempo de Sincronización**: < 5 segundos

## Escalabilidad

### Crecimiento Horizontal

La arquitectura permite:

1. **Agregar nuevas páginas**: Crear componente en `src/pages/`
2. **Agregar nuevos servicios**: Crear módulo en `src/lib/`
3. **Agregar nuevas tablas**: Extender esquema SQLite
4. **Agregar nuevos hooks**: Crear en `src/hooks/`

### Crecimiento Vertical

- Soporte para múltiples usuarios
- Sincronización de múltiples dispositivos
- Integración con múltiples LLMs
- Soporte para múltiples modelos de IA

## Diagrama de Componentes

```
┌─────────────────────────────────────────┐
│         Tauri Desktop Window            │
├─────────────────────────────────────────┤
│                                         │
│  ┌──────────────────────────────────┐  │
│  │      React Frontend (UI)         │  │
│  │  ┌────────────────────────────┐  │  │
│  │  │  TabBar (Navigation)       │  │  │
│  │  │  - Chat, Patterns, etc.    │  │  │
│  │  └────────────────────────────┘  │  │
│  │                                  │  │
│  │  ┌────────────────────────────┐  │  │
│  │  │  Pages (Components)        │  │  │
│  │  │  - ChatPage                │  │  │
│  │  │  - PatternsPage            │  │  │
│  │  │  - KnowledgePage           │  │  │
│  │  │  - RetrainingPage          │  │  │
│  │  │  - SettingsPage            │  │  │
│  │  └────────────────────────────┘  │  │
│  └──────────────────────────────────┘  │
│                  ↓                      │
│  ┌──────────────────────────────────┐  │
│  │  Zustand State Management        │  │
│  │  - appStore                      │  │
│  └──────────────────────────────────┘  │
│                  ↓                      │
│  ┌──────────────────────────────────┐  │
│  │  Services & Hooks                │  │
│  │  - sync.ts                       │  │
│  │  - animalHierarchy.ts            │  │
│  │  - useSyncManager.ts             │  │
│  └──────────────────────────────────┘  │
│                  ↓                      │
│  ┌──────────────────────────────────┐  │
│  │  Data Layer                      │  │
│  │  ┌────────────────────────────┐  │  │
│  │  │  SQLite (Local)            │  │  │
│  │  │  - Offline Storage         │  │  │
│  │  └────────────────────────────┘  │  │
│  │  ┌────────────────────────────┐  │  │
│  │  │  Axios (HTTP Client)       │  │  │
│  │  │  - Sync with Hosting       │  │  │
│  │  └────────────────────────────┘  │  │
│  └──────────────────────────────────┘  │
│                  ↓                      │
│  ┌──────────────────────────────────┐  │
│  │  Tauri Runtime (Rust)            │  │
│  │  - Window Management             │  │
│  │  - OS Integration                │  │
│  └──────────────────────────────────┘  │
│                                         │
└─────────────────────────────────────────┘
         ↓
    ┌─────────────────┐
    │ Operating System│
    │ (Windows/Mac/   │
    │  Linux)         │
    └─────────────────┘
         ↓
    ┌─────────────────────────────┐
    │ Hosting (torete.net/v3/)    │
    │ - API Endpoints             │
    │ - Data Synchronization      │
    │ - Model Training            │
    └─────────────────────────────┘
```

## Conclusión

La arquitectura de Animalia Desktop App está diseñada para ser **modular, escalable y preparada para el futuro**. Permite desarrollo rápido, mantenimiento fácil y extensiones sin comprometer el rendimiento o la experiencia del usuario.
