# Guía de Instalación - Animalia Desktop App

Esta guía te ayudará a compilar e instalar Animalia Desktop App en tu plataforma.

## 📋 Requisitos Previos (Todas las Plataformas)

### Node.js y npm
- **Descarga**: https://nodejs.org/ (versión 18 o superior)
- **Verificar instalación**: `node --version` y `npm --version`

### Rust
- **Descarga**: https://rustup.rs/
- **Verificar instalación**: `rustc --version`

---

## 🪟 Windows

### Requisitos Adicionales
- Windows 10 o superior
- Visual Studio Build Tools (incluye compilador C++)

### Pasos de Instalación

1. **Descarga el proyecto**
   ```bash
   git clone https://github.com/yoqer/animalia-desktop-app.git
   cd animalia-desktop-app
   ```

2. **Ejecuta el script de compilación**
   ```powershell
   .\build-windows.ps1
   ```

3. **Espera a que se complete la compilación**
   - Esto puede tomar 5-10 minutos en la primera ejecución

4. **Busca el instalador**
   - Ubicación: `src-tauri/target/release/bundle/msi/`
   - Archivo: `Animalia_Desktop_App_*.msi`

5. **Instala la aplicación**
   - Haz doble clic en el archivo `.msi`
   - Sigue el asistente de instalación
   - Selecciona la carpeta de destino
   - Haz clic en "Instalar"

6. **Ejecuta la aplicación**
   - Busca "Animalia" en el menú Inicio
   - O haz clic en el acceso directo del escritorio

### Solución de Problemas en Windows

**Error: "PowerShell no puede ejecutar scripts"**
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

**Error: "Visual Studio Build Tools no encontrado"**
- Descarga desde: https://visualstudio.microsoft.com/downloads/
- Selecciona "Desktop development with C++"

---

## 🍎 macOS

### Requisitos Adicionales
- macOS 10.13 o superior
- Xcode Command Line Tools: `xcode-select --install`

### Pasos de Instalación

1. **Descarga el proyecto**
   ```bash
   git clone https://github.com/yoqer/animalia-desktop-app.git
   cd animalia-desktop-app
   ```

2. **Ejecuta el script de compilación**
   ```bash
   chmod +x build-macos.sh
   ./build-macos.sh
   ```

3. **Espera a que se complete la compilación**
   - Esto puede tomar 10-15 minutos

4. **Busca el paquete DMG**
   - Ubicación: `src-tauri/target/release/bundle/dmg/`
   - Archivo: `Animalia_Desktop_App_*.dmg`

5. **Instala la aplicación**
   - Haz doble clic en el archivo `.dmg`
   - Arrastra el icono de Animalia a la carpeta "Aplicaciones"
   - Espera a que se copie

6. **Ejecuta la aplicación**
   - Abre Finder → Aplicaciones
   - Busca "Animalia Desktop App"
   - Haz doble clic para ejecutar

### Nota sobre Seguridad en macOS

Si ves "No se puede abrir porque el desarrollador no está verificado":
1. Abre Preferencias del Sistema → Seguridad y privacidad
2. Haz clic en "Abrir de todas formas"

---

## 🐧 Linux

### Requisitos Adicionales (Ubuntu/Debian)
```bash
sudo apt-get update
sudo apt-get install -y \
  build-essential \
  libssl-dev \
  pkg-config \
  libgtk-3-dev \
  libwebkit2gtk-4.0-dev
```

### Pasos de Instalación

1. **Descarga el proyecto**
   ```bash
   git clone https://github.com/yoqer/animalia-desktop-app.git
   cd animalia-desktop-app
   ```

2. **Ejecuta el script de compilación**
   ```bash
   chmod +x build-linux.sh
   ./build-linux.sh
   ```

3. **Espera a que se complete la compilación**
   - Esto puede tomar 10-15 minutos

4. **Elige tu método de instalación**

#### Opción A: AppImage (Recomendado)
```bash
# Busca el archivo AppImage
ls src-tauri/target/release/bundle/appimage/

# Haz ejecutable
chmod +x Animalia_Desktop_App_*.AppImage

# Ejecuta directamente
./Animalia_Desktop_App_*.AppImage
```

#### Opción B: .deb (Debian/Ubuntu)
```bash
# Instala el paquete
sudo apt install ./src-tauri/target/release/bundle/deb/*.deb

# Ejecuta desde el menú de aplicaciones o con:
animalia-desktop-app
```

---

## 🤖 Android

### Requisitos Adicionales
- Android Studio instalado
- Android SDK configurado
- Variable de entorno `ANDROID_SDK_ROOT` configurada

### Configuración de ANDROID_SDK_ROOT

**Linux/macOS:**
```bash
export ANDROID_SDK_ROOT=$HOME/Android/Sdk
```

**Windows (PowerShell):**
```powershell
$env:ANDROID_SDK_ROOT = "$env:USERPROFILE\AppData\Local\Android\Sdk"
```

### Pasos de Instalación

1. **Descarga el proyecto**
   ```bash
   git clone https://github.com/yoqer/animalia-desktop-app.git
   cd animalia-desktop-app
   ```

2. **Ejecuta el script de compilación**
   ```bash
   chmod +x build-android.sh
   ./build-android.sh
   ```

3. **Espera a que se complete la compilación**
   - Esto puede tomar 15-20 minutos

4. **Busca el APK**
   - Ubicación: `src-tauri/target/release/bundle/apk/`
   - Archivo: `animalia-desktop-app.apk`

5. **Instala en tu dispositivo**

#### Opción A: Transferencia Manual
- Transfiere el APK a tu dispositivo Android
- Abre el archivo con tu gestor de archivos
- Toca "Instalar"
- Permite la instalación desde fuentes desconocidas si es necesario

#### Opción B: ADB (Recomendado)
```bash
# Conecta tu dispositivo Android
adb devices

# Instala el APK
adb install -r src-tauri/target/release/bundle/apk/animalia-desktop-app.apk
```

---

## 🍎 iOS

### Requisitos Adicionales
- **Solo en macOS** (no se puede compilar en Windows/Linux)
- Xcode instalado (descarga desde App Store)
- Cuenta de Apple Developer (para publicar en App Store)

### Pasos de Instalación

1. **Descarga el proyecto**
   ```bash
   git clone https://github.com/yoqer/animalia-desktop-app.git
   cd animalia-desktop-app
   ```

2. **Ejecuta el script de compilación** (solo en macOS)
   ```bash
   chmod +x build-ios.sh
   ./build-ios.sh
   ```

3. **Espera a que se complete la compilación**
   - Esto puede tomar 15-20 minutos

4. **Busca el IPA**
   - Ubicación: `src-tauri/target/release/bundle/ios/`
   - Archivo: `Animalia_Desktop_App_*.ipa`

5. **Instala en tu dispositivo**

#### Opción A: Xcode
1. Abre Xcode
2. Ve a Window → Devices and Simulators
3. Selecciona tu dispositivo iOS
4. Arrastra el archivo `.ipa` al dispositivo

#### Opción B: Transporter (Recomendado)
1. Descarga Transporter desde la App Store
2. Abre Transporter
3. Haz clic en "Seleccionar aplicación"
4. Elige el archivo `.ipa`
5. Inicia sesión con tu cuenta de Apple Developer
6. Haz clic en "Enviar"

#### Opción C: TestFlight (para pruebas)
1. Sube el IPA a App Store Connect
2. Asigna a TestFlight
3. Invita a probadores
4. Los probadores instalan desde TestFlight

---

## 🔧 Compilación Personalizada

### Compilar solo para tu arquitectura

**macOS (Apple Silicon):**
```bash
rustup target add aarch64-apple-darwin
npm run build -- --target aarch64-apple-darwin
```

**macOS (Intel):**
```bash
rustup target add x86_64-apple-darwin
npm run build -- --target x86_64-apple-darwin
```

**Linux (x86_64):**
```bash
rustup target add x86_64-unknown-linux-gnu
npm run build -- --target x86_64-unknown-linux-gnu
```

---

## 📦 Distribución

### Crear un ZIP para compartir

```bash
# Windows
Compress-Archive -Path dist\windows -DestinationPath animalia-windows.zip

# macOS/Linux
zip -r animalia-macos.zip dist/macos
zip -r animalia-linux.zip dist/linux
```

---

## ❓ Preguntas Frecuentes

**P: ¿Cuánto espacio necesita la aplicación?**
R: Aproximadamente 50-80 MB según la plataforma.

**P: ¿Puedo usar la aplicación sin conexión a internet?**
R: Sí, funciona completamente offline. La sincronización es automática cuando hay conexión.

**P: ¿Es segura la aplicación?**
R: Sí, todos los datos se almacenan localmente en SQLite. No se envía información personal sin tu consentimiento.

**P: ¿Cómo actualizo la aplicación?**
R: Descarga la última versión y sigue los pasos de instalación nuevamente.

**P: ¿Puedo compilar en una plataforma diferente?**
R: Windows y Linux pueden compilarse en cualquier plataforma con Rust. iOS solo en macOS.

---

## 📞 Soporte

Si encuentras problemas:
1. Verifica que tienes todas las dependencias instaladas
2. Ejecuta `npm install` nuevamente
3. Limpia la caché: `rm -rf node_modules dist src-tauri/target`
4. Intenta compilar nuevamente

Para reportar bugs: https://github.com/yoqer/animalia-desktop-app/issues
