#!/bin/bash

# Animalia Desktop App - iOS Build Script
# Este script compila la aplicación para iOS (IPA)
# NOTA: Solo se puede ejecutar en macOS con Xcode instalado

echo "╔════════════════════════════════════════════════════════════╗"
echo "║   Animalia Desktop App - Compilación para iOS             ║"
echo "╚════════════════════════════════════════════════════════════╝"

# Verificar si se está ejecutando en macOS
echo ""
echo "[1/7] Verificando sistema operativo..."
if [[ "$OSTYPE" != "darwin"* ]]; then
    echo "ERROR: Este script solo funciona en macOS"
    echo "iOS solo se puede compilar en macOS con Xcode instalado"
    exit 1
fi
echo "✓ macOS detectado"

# Verificar si Xcode está instalado
echo ""
echo "[2/7] Verificando Xcode..."
if ! command -v xcode-select &> /dev/null; then
    echo "ERROR: Xcode no está instalado"
    echo "Instálalo desde la App Store o descárgalo desde https://developer.apple.com/download/"
    exit 1
fi
echo "✓ Xcode encontrado"

# Verificar si Node.js está instalado
echo ""
echo "[3/7] Verificando Node.js..."
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js no está instalado"
    exit 1
fi
echo "✓ Node.js encontrado: $(node --version)"

# Verificar si Rust está instalado
echo ""
echo "[4/7] Verificando Rust..."
if ! command -v rustc &> /dev/null; then
    echo "ERROR: Rust no está instalado"
    exit 1
fi
echo "✓ Rust encontrado: $(rustc --version)"

# Instalar targets de Rust para iOS
echo ""
echo "[5/7] Configurando Rust para iOS..."
rustup target add aarch64-apple-ios x86_64-apple-ios aarch64-apple-ios-sim
if [ $? -ne 0 ]; then
    echo "ERROR: Fallo al configurar Rust"
    exit 1
fi
echo "✓ Targets configurados"

# Instalar dependencias
echo ""
echo "[6/7] Instalando dependencias..."
npm install
if [ $? -ne 0 ]; then
    echo "ERROR: Fallo al instalar dependencias"
    exit 1
fi
echo "✓ Dependencias instaladas"

# Compilar la aplicación
echo ""
echo "[7/7] Compilando aplicación para iOS..."
npm run build -- --target ios
if [ $? -ne 0 ]; then
    echo "ERROR: Fallo al compilar"
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║   ✓ Compilación completada exitosamente                   ║"
echo "║   El IPA está listo para descargar                        ║"
echo "╚════════════════════════════════════════════════════════════╝"

echo ""
echo "Pasos siguientes:"
echo "1. Busca el archivo .ipa en: src-tauri/target/release/bundle/ios/"
echo "2. Abre Xcode y ve a Window > Devices and Simulators"
echo "3. Selecciona tu dispositivo iOS"
echo "4. Arrastra el archivo .ipa al dispositivo"
echo ""
echo "O usa Transporter:"
echo "1. Descarga Transporter desde la App Store"
echo "2. Abre el archivo .ipa con Transporter"
echo "3. Inicia sesión con tu cuenta de Apple Developer"
echo "4. Envía a App Store Connect"
