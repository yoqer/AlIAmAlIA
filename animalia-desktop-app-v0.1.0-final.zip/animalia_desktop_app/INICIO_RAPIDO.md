# Inicio Rápido - Animalia Desktop App

Comienza a usar Animalia Desktop App en 5 minutos.

## 🚀 Instalación Rápida

### Windows
1. Descarga `Animalia_Desktop_App_0.1.0.msi`
2. Haz doble clic para instalar
3. Sigue el asistente
4. ¡Listo!

### macOS
1. Descarga `Animalia_Desktop_App_0.1.0.dmg`
2. Haz doble clic para montar
3. Arrastra a Aplicaciones
4. ¡Listo!

### Linux (AppImage)
1. Descarga `Animalia_Desktop_App_0.1.0_amd64.AppImage`
2. `chmod +x Animalia_Desktop_App_0.1.0_amd64.AppImage`
3. `./Animalia_Desktop_App_0.1.0_amd64.AppImage`
4. ¡Listo!

### Linux (DEB)
1. Descarga `animalia-desktop-app_0.1.0_amd64.deb`
2. `sudo apt install ./animalia-desktop-app_0.1.0_amd64.deb`
3. Busca "Animalia" en tu menú de aplicaciones
4. ¡Listo!

### Android
1. Descarga `animalia-desktop-app.apk`
2. Abre el archivo en tu dispositivo
3. Toca "Instalar"
4. ¡Listo!

### iOS
1. Descarga `Animalia_Desktop_App_0.1.0.ipa`
2. Abre con Transporter o Xcode
3. Sigue las instrucciones
4. ¡Listo!

## 📱 Primera Ejecución

Al abrir Animalia por primera vez:

1. **Pantalla de Inicio**: Verás la interfaz con 5 pestañas
2. **Chat**: Comienza a escribir mensajes
3. **Patrones**: Explora patrones de comportamiento animal
4. **Conocimiento**: Importa datos de entrenamiento
5. **Reentreno**: Solicita reentrenamiento de modelos
6. **Ajustes**: Configura tu conexión a hosting

## 💬 Chat RAG

### Usar el Chat

1. Ve a la pestaña **Chat**
2. Escribe tu pregunta o mensaje
3. Presiona Enter o toca el botón Enviar
4. Espera la respuesta

### Crear Nueva Conversación

1. Toca el botón **+** en la esquina superior derecha
2. Se creará una nueva conversación
3. Comienza a escribir

## 🔍 Explorar Patrones

1. Ve a la pestaña **Patrones**
2. Usa la barra de búsqueda para encontrar especies
3. Filtra por categoría (Comunicación, Alimentación, etc.)
4. Toca un patrón para ver detalles

## 📚 Gestión de Conocimiento

### Agregar Conocimiento Manual

1. Ve a la pestaña **Conocimiento**
2. Toca el botón **+**
3. Selecciona el tipo (Comportamiento, Comunicación, etc.)
4. Escribe título y contenido
5. Toca "Guardar"

### Importar JSON

1. Ve a la pestaña **Conocimiento**
2. Toca el botón **Importar JSON**
3. Selecciona tu archivo JSON
4. Los datos se importarán automáticamente

## ⚡ Solicitar Reentreno

1. Ve a la pestaña **Reentreno**
2. Toca **Nueva Solicitud**
3. Selecciona prioridad (Normal, Alta, Urgente)
4. Elige el modelo objetivo (Visión, Chat, Todos)
5. Toca **Enviar Solicitud**
6. Monitorea el progreso

## ⚙️ Configuración

### Conectar a Hosting

1. Ve a la pestaña **Ajustes**
2. En "Conexión a Hosting", ingresa la URL
3. Por defecto: `https://torete.net/animaliav3`
4. Toca "Guardar Configuración"

### Habilitar Sincronización Automática

1. Ve a la pestaña **Ajustes**
2. Marca "Sincronización automática"
3. Ajusta el intervalo (en segundos)
4. Toca "Guardar Configuración"

### Usar LLM Local

1. Ve a la pestaña **Ajustes**
2. Marca "Habilitar LLM local"
3. Ingresa el endpoint (ej. `http://localhost:8000`)
4. Especifica el modelo (ej. `llama2`)
5. Toca "Guardar Configuración"

## 🔄 Sincronización

### Sincronización Automática

- Se ejecuta cada X segundos (configurable)
- Se ejecuta al iniciar la app
- Funciona en segundo plano
- No interrumpe tu trabajo

### Sincronización Manual

1. Ve a la pestaña **Ajustes**
2. Busca el botón de sincronización
3. Toca para sincronizar inmediatamente

## 💾 Respaldo de Datos

### Exportar Datos

1. Ve a la pestaña **Ajustes**
2. Busca "Exportación/Importación"
3. Toca "Exportar JSON"
4. Se descargará un archivo JSON con todos tus datos

### Importar Datos

1. Ve a la pestaña **Ajustes**
2. Busca "Exportación/Importación"
3. Toca "Importar JSON"
4. Selecciona tu archivo de respaldo
5. Los datos se restaurarán

## 🆘 Solución Rápida de Problemas

### La app no inicia
- Intenta desinstalar y reinstalar
- Verifica que tienes espacio suficiente (50-80 MB)
- Reinicia tu dispositivo

### No se sincroniza
- Verifica tu conexión a internet
- Comprueba la URL del hosting en Ajustes
- Intenta sincronizar manualmente

### El chat no responde
- Espera unos segundos
- Verifica tu conexión a internet
- Intenta reiniciar la app

### No puedo importar JSON
- Verifica que el archivo sea JSON válido
- Comprueba la estructura del archivo
- Intenta con un archivo de ejemplo

## 📞 Obtener Ayuda

- **Documentación**: Lee `README.md` para más información
- **Guía de Instalación**: Consulta `GUIA_INSTALACION.md`
- **Guía de Compilación**: Consulta `COMPILACION.md`
- **Arquitectura**: Lee `ARQUITECTURA.md` para detalles técnicos

## 🎯 Próximos Pasos

1. **Explora todas las pestañas**: Familiarízate con la interfaz
2. **Configura tu hosting**: Conecta a tu servidor
3. **Importa datos**: Carga tus datos de entrenamiento
4. **Solicita reentreno**: Mejora tus modelos
5. **Sincroniza regularmente**: Mantén tus datos actualizados

## 💡 Consejos

- La app funciona offline, pero la sincronización requiere internet
- Los datos se guardan localmente en SQLite
- Realiza respaldos regularmente
- Actualiza la app cuando haya nuevas versiones
- Reporta bugs para ayudarnos a mejorar

¡Disfruta usando Animalia Desktop App! 🎉
