# Guía de Compilación con GitHub Actions

Esta guía explica cómo usar GitHub Actions para compilar automáticamente Animalia Desktop App para todas las plataformas **sin necesidad de instalar Rust localmente**.

## 🎯 ¿Qué es GitHub Actions?

GitHub Actions es un servicio de automatización de GitHub que:
- Compila tu código automáticamente
- Genera instaladores para todas las plataformas
- Los descarga automáticamente
- **No requiere Rust instalado en tu máquina**

## 📋 Requisitos Previos

1. **Cuenta de GitHub** (gratuita)
2. **Git instalado** en tu máquina
3. **Acceso al repositorio** (tu propio repositorio o fork)

## 🚀 Pasos para Compilar con GitHub Actions

### Paso 1: Subir el Código a GitHub

```bash
# Clonar o navegar al repositorio
cd animalia_desktop_app

# Inicializar git si no está inicializado
git init

# Agregar el repositorio remoto
git remote add origin https://github.com/TU_USUARIO/animalia-desktop-app.git

# Agregar todos los archivos
git add .

# Hacer commit
git commit -m "Initial commit: Animalia Desktop App v0.1.0"

# Subir a GitHub
git push -u origin main
```

### Paso 2: Crear una Etiqueta de Versión

GitHub Actions se activa cuando creas una etiqueta con formato `v*` (ej: v0.1.0).

```bash
# Crear etiqueta
git tag v0.1.0

# Subir etiqueta a GitHub
git push origin v0.1.0
```

### Paso 3: Monitorear la Compilación

1. Ve a tu repositorio en GitHub
2. Haz clic en la pestaña **"Actions"**
3. Verás un flujo de trabajo llamado "Build Animalia Desktop App"
4. Espera a que se complete (10-30 minutos)

### Paso 4: Descargar los Instaladores

Una vez completada la compilación:

1. Ve a **"Releases"** en tu repositorio
2. Busca la versión `v0.1.0`
3. Descarga los instaladores que necesites:
   - `Animalia_Desktop_App_0.1.0.msi` (Windows)
   - `Animalia_Desktop_App_0.1.0_x64.dmg` (macOS Intel)
   - `Animalia_Desktop_App_0.1.0_aarch64.dmg` (macOS Apple Silicon)
   - `Animalia_Desktop_App_0.1.0_amd64.AppImage` (Linux)
   - `animalia-desktop-app_0.1.0_amd64.deb` (Linux Debian)
   - `animalia-desktop-app-0.1.0.apk` (Android)
   - `Animalia_Desktop_App_0.1.0.ipa` (iOS)

## 📊 Estructura del Flujo de Trabajo

El archivo `.github/workflows/build.yml` compila automáticamente para:

| Plataforma | Tiempo | Requisitos |
|-----------|--------|-----------|
| Windows | 10-15 min | Windows Latest |
| macOS | 15-20 min | macOS Latest |
| Linux | 10-15 min | Ubuntu Latest |
| Android | 15-20 min | Ubuntu Latest + Android SDK |
| iOS | 15-20 min | macOS Latest + Xcode |

**Tiempo Total**: ~30-60 minutos (en paralelo)

## 🔄 Compilar Nuevamente

Para compilar una nueva versión:

```bash
# Hacer cambios en el código
# ...

# Commit
git add .
git commit -m "Descripción de cambios"
git push

# Crear nueva etiqueta
git tag v0.2.0
git push origin v0.2.0
```

GitHub Actions compilará automáticamente la nueva versión.

## 🛠️ Personalizar la Compilación

### Cambiar Versión

Edita `package.json`:
```json
{
  "version": "0.2.0"
}
```

### Cambiar Nombre de la Aplicación

Edita `tauri.conf.json`:
```json
{
  "productName": "Mi Animalia App"
}
```

### Agregar Plataformas Adicionales

Edita `.github/workflows/build.yml` y agrega nuevos jobs.

## 📝 Ejemplo Completo

```bash
# 1. Clonar o crear repositorio
git clone https://github.com/TU_USUARIO/animalia-desktop-app.git
cd animalia-desktop-app

# 2. Hacer cambios (opcional)
# Edita archivos según sea necesario

# 3. Commit
git add .
git commit -m "Animalia Desktop App v0.1.0"
git push

# 4. Crear etiqueta
git tag v0.1.0
git push origin v0.1.0

# 5. Esperar compilación (10-30 minutos)
# Ve a: https://github.com/TU_USUARIO/animalia-desktop-app/actions

# 6. Descargar instaladores
# Ve a: https://github.com/TU_USUARIO/animalia-desktop-app/releases
```

## ❓ Preguntas Frecuentes

**P: ¿Cuánto tiempo toma compilar?**
R: 30-60 minutos en total (todas las plataformas en paralelo).

**P: ¿Cuesta dinero?**
R: No, GitHub Actions es gratuito para repositorios públicos.

**P: ¿Puedo compilar solo para una plataforma?**
R: Sí, edita `.github/workflows/build.yml` y comenta los jobs que no necesites.

**P: ¿Qué pasa si la compilación falla?**
R: Verás el error en la pestaña "Actions". Revisa los logs para saber qué salió mal.

**P: ¿Puedo compilar sin crear una etiqueta?**
R: Sí, edita `.github/workflows/build.yml` y cambia `on: push: tags:` a `on: push: branches: [main]`.

**P: ¿Los instaladores son seguros?**
R: Sí, se generan a partir de tu código en GitHub. Puedes verificar el código fuente.

## 🔐 Seguridad

- Los instaladores se generan en servidores de GitHub
- Tu código fuente es público (si el repositorio es público)
- No se almacenan secretos en el repositorio
- Los instaladores se descargan directamente desde GitHub

## 📞 Solución de Problemas

### Error: "Workflow file not found"
- Asegúrate de que el archivo `.github/workflows/build.yml` existe
- Verifica que está en la rama correcta

### Error: "Build failed"
- Ve a la pestaña "Actions"
- Haz clic en el flujo de trabajo fallido
- Lee los logs para ver el error específico

### Los instaladores no aparecen
- Espera a que se complete la compilación
- Actualiza la página de Releases
- Verifica que creaste una etiqueta (v0.1.0, v0.2.0, etc.)

## 🎯 Próximos Pasos

1. **Sube el código a GitHub**
2. **Crea una etiqueta de versión**
3. **Espera a que se compile**
4. **Descarga los instaladores**
5. **Comparte con usuarios**

## 📚 Recursos Adicionales

- [Documentación de GitHub Actions](https://docs.github.com/en/actions)
- [Documentación de Tauri](https://tauri.app/docs/)
- [Guía de Releases en GitHub](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository)

¡Listo! Ahora puedes compilar Animalia Desktop App para todas las plataformas sin instalar Rust. 🎉
