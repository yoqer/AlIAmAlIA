# Descarga e Instalación - Animalia Desktop App v0.1.0

## 📥 Descargas Disponibles

### Paquete Completo (Código Fuente)
- **Archivo**: `animalia-desktop-app-v0.1.0-complete.zip` (48 KB)
- **Contenido**: Código fuente completo + scripts de compilación
- **Uso**: Para compilar la aplicación en tu máquina
- **Requisitos**: Node.js, Rust, herramientas de compilación

### Instaladores Compilados (Por Plataforma)

#### Windows
- **Archivo**: `Animalia_Desktop_App_0.1.0.msi` (~70 MB)
- **Tipo**: Instalador autoinstalable
- **Requisitos**: Windows 10 o superior
- **Instalación**: Doble clic en el archivo

#### macOS (Intel)
- **Archivo**: `Animalia_Desktop_App_0.1.0_x64.dmg` (~80 MB)
- **Tipo**: Paquete DMG
- **Requisitos**: macOS 10.13 o superior
- **Instalación**: Doble clic y arrastra a Aplicaciones

#### macOS (Apple Silicon - M1/M2/M3)
- **Archivo**: `Animalia_Desktop_App_0.1.0_aarch64.dmg` (~80 MB)
- **Tipo**: Paquete DMG
- **Requisitos**: macOS 10.13 o superior (M1/M2/M3)
- **Instalación**: Doble clic y arrastra a Aplicaciones

#### Linux (AppImage)
- **Archivo**: `Animalia_Desktop_App_0.1.0_amd64.AppImage` (~65 MB)
- **Tipo**: AppImage ejecutable
- **Requisitos**: Linux con glibc 2.29+
- **Instalación**: Hacer ejecutable y ejecutar

#### Linux (Debian/Ubuntu)
- **Archivo**: `animalia-desktop-app_0.1.0_amd64.deb` (~55 MB)
- **Tipo**: Paquete Debian
- **Requisitos**: Ubuntu 18.04+ o Debian 10+
- **Instalación**: `sudo apt install ./archivo.deb`

#### Android
- **Archivo**: `animalia-desktop-app-0.1.0.apk` (~60 MB)
- **Tipo**: APK de Android
- **Requisitos**: Android 7.0 (API 24) o superior
- **Instalación**: Transferir a dispositivo y abrir

#### iOS
- **Archivo**: `Animalia_Desktop_App_0.1.0.ipa` (~75 MB)
- **Tipo**: IPA de iOS
- **Requisitos**: iOS 13.0 o superior
- **Instalación**: Usar Transporter o Xcode

---

## 🪟 Instalación en Windows

### Método 1: Instalador MSI (Recomendado)

1. **Descarga el archivo**
   - `Animalia_Desktop_App_0.1.0.msi`

2. **Ejecuta el instalador**
   - Haz doble clic en el archivo `.msi`
   - Se abrirá el asistente de instalación

3. **Sigue los pasos**
   - Acepta los términos de licencia
   - Selecciona la carpeta de destino (por defecto: `C:\Program Files`)
   - Haz clic en "Instalar"
   - Espera a que se complete

4. **Inicia la aplicación**
   - Busca "Animalia" en el menú Inicio
   - O haz clic en el acceso directo del escritorio
   - ¡La aplicación se abrirá!

### Método 2: Compilar desde Código Fuente

1. **Descarga el código fuente**
   - `animalia-desktop-app-v0.1.0-complete.zip`

2. **Extrae el archivo**
   - Haz clic derecho → "Extraer todo"
   - Selecciona la carpeta de destino

3. **Abre PowerShell**
   - Navega a la carpeta del proyecto
   - `cd C:\ruta\a\animalia_desktop_app`

4. **Ejecuta el script de compilación**
   ```powershell
   .\build-windows.ps1
   ```

5. **Espera a que se compile**
   - Esto toma 10-15 minutos la primera vez
   - El instalador se generará automáticamente

6. **Busca el instalador**
   - Ubicación: `src-tauri/target/release/bundle/msi/`
   - Instala como se describe arriba

---

## 🍎 Instalación en macOS

### Método 1: Paquete DMG (Recomendado)

1. **Descarga el archivo**
   - `Animalia_Desktop_App_0.1.0_x64.dmg` (Intel)
   - O `Animalia_Desktop_App_0.1.0_aarch64.dmg` (Apple Silicon)

2. **Abre el archivo**
   - Haz doble clic en el archivo `.dmg`
   - Se montará la imagen

3. **Instala la aplicación**
   - Arrastra el icono de Animalia a la carpeta "Aplicaciones"
   - Espera a que se copie (puede tomar 1-2 minutos)

4. **Inicia la aplicación**
   - Abre Finder → Aplicaciones
   - Busca "Animalia Desktop App"
   - Haz doble clic para ejecutar

5. **Nota de Seguridad**
   - Si ves "No se puede abrir porque el desarrollador no está verificado":
     - Abre Preferencias del Sistema → Seguridad y privacidad
     - Haz clic en "Abrir de todas formas"

### Método 2: Compilar desde Código Fuente

1. **Descarga el código fuente**
   - `animalia-desktop-app-v0.1.0-complete.zip`

2. **Extrae el archivo**
   - Haz doble clic en el ZIP
   - Se extraerá automáticamente

3. **Abre Terminal**
   - Navega a la carpeta del proyecto
   - `cd /ruta/a/animalia_desktop_app`

4. **Ejecuta el script de compilación**
   ```bash
   chmod +x build-macos.sh
   ./build-macos.sh
   ```

5. **Espera a que se compile**
   - Esto toma 12-18 minutos la primera vez

6. **Busca el paquete DMG**
   - Ubicación: `src-tauri/target/release/bundle/dmg/`
   - Instala como se describe arriba

---

## 🐧 Instalación en Linux

### Método 1: AppImage (Recomendado)

1. **Descarga el archivo**
   - `Animalia_Desktop_App_0.1.0_amd64.AppImage`

2. **Haz el archivo ejecutable**
   ```bash
   chmod +x Animalia_Desktop_App_0.1.0_amd64.AppImage
   ```

3. **Ejecuta la aplicación**
   ```bash
   ./Animalia_Desktop_App_0.1.0_amd64.AppImage
   ```

4. **Crear acceso directo (opcional)**
   ```bash
   # Copiar a /opt
   sudo cp Animalia_Desktop_App_0.1.0_amd64.AppImage /opt/animalia

   # Crear acceso directo en el menú
   sudo ln -s /opt/animalia /usr/bin/animalia
   ```

### Método 2: Paquete DEB (Ubuntu/Debian)

1. **Descarga el archivo**
   - `animalia-desktop-app_0.1.0_amd64.deb`

2. **Instala el paquete**
   ```bash
   sudo apt install ./animalia-desktop-app_0.1.0_amd64.deb
   ```

3. **Inicia la aplicación**
   - Busca "Animalia" en tu menú de aplicaciones
   - O ejecuta: `animalia-desktop-app`

### Método 3: Compilar desde Código Fuente

1. **Descarga el código fuente**
   - `animalia-desktop-app-v0.1.0-complete.zip`

2. **Extrae el archivo**
   ```bash
   unzip animalia-desktop-app-v0.1.0-complete.zip
   cd animalia_desktop_app
   ```

3. **Ejecuta el script de compilación**
   ```bash
   chmod +x build-linux.sh
   ./build-linux.sh
   ```

4. **Espera a que se compile**
   - Esto toma 10-15 minutos la primera vez

5. **Busca los instaladores**
   - AppImage: `src-tauri/target/release/bundle/appimage/`
   - DEB: `src-tauri/target/release/bundle/deb/`

---

## 🤖 Instalación en Android

### Método 1: Instalación Manual

1. **Descarga el archivo**
   - `animalia-desktop-app-0.1.0.apk`

2. **Transfiere a tu dispositivo**
   - Usa cable USB o descarga directamente en el dispositivo

3. **Abre el archivo**
   - Busca el archivo en tu gestor de archivos
   - Toca el archivo `.apk`

4. **Instala la aplicación**
   - Toca "Instalar"
   - Si ves una advertencia, marca "Instalar desde fuentes desconocidas"
   - Espera a que se complete

5. **Inicia la aplicación**
   - Busca "Animalia" en tu pantalla de inicio
   - O en el menú de aplicaciones

### Método 2: Instalación con ADB

1. **Descarga el archivo**
   - `animalia-desktop-app-0.1.0.apk`

2. **Conecta tu dispositivo**
   ```bash
   adb devices
   ```

3. **Instala el APK**
   ```bash
   adb install -r animalia-desktop-app-0.1.0.apk
   ```

4. **Inicia la aplicación**
   - Busca "Animalia" en tu dispositivo

---

## 🍎 Instalación en iOS

### Método 1: Transporter (Recomendado)

1. **Descarga el archivo**
   - `Animalia_Desktop_App_0.1.0.ipa`

2. **Descarga Transporter**
   - Abre App Store en tu Mac
   - Busca "Transporter"
   - Descarga e instala

3. **Abre el archivo con Transporter**
   - Abre Transporter
   - Haz clic en "Seleccionar aplicación"
   - Elige el archivo `.ipa`

4. **Inicia sesión**
   - Inicia sesión con tu cuenta de Apple Developer

5. **Envía la aplicación**
   - Haz clic en "Enviar"
   - Espera a que se complete

### Método 2: Xcode

1. **Descarga el archivo**
   - `Animalia_Desktop_App_0.1.0.ipa`

2. **Abre Xcode**
   - Conecta tu dispositivo iOS
   - Ve a Window → Devices and Simulators

3. **Instala la aplicación**
   - Selecciona tu dispositivo
   - Arrastra el archivo `.ipa` al dispositivo
   - Espera a que se instale

4. **Inicia la aplicación**
   - Busca "Animalia" en tu dispositivo

### Método 3: TestFlight (para pruebas)

1. **Descarga el archivo**
   - `Animalia_Desktop_App_0.1.0.ipa`

2. **Sube a App Store Connect**
   - Inicia sesión en https://appstoreconnect.apple.com
   - Ve a "Mi Aplicaciones"
   - Sube el IPA

3. **Asigna a TestFlight**
   - Selecciona la versión
   - Haz clic en "Asignar a TestFlight"

4. **Invita a probadores**
   - Agrega direcciones de correo de probadores
   - Envía invitaciones

5. **Instala en tu dispositivo**
   - Los probadores reciben un enlace
   - Descargan TestFlight
   - Instalan la aplicación desde TestFlight

---

## ✅ Verificación de Instalación

Después de instalar, verifica que todo funciona:

1. **Abre la aplicación**
   - Busca el icono de Animalia
   - Haz clic para ejecutar

2. **Verifica las pestañas**
   - Deberías ver 5 pestañas: Chat, Patrones, Conocimiento, Reentreno, Ajustes

3. **Prueba el chat**
   - Ve a la pestaña Chat
   - Escribe un mensaje de prueba
   - Deberías recibir una respuesta

4. **Verifica la sincronización**
   - Ve a Ajustes
   - Verifica que la URL de hosting está configurada
   - Intenta sincronizar manualmente

---

## 🆘 Solución de Problemas

### La descarga no funciona
- Verifica tu conexión a internet
- Intenta descargar nuevamente
- Usa un navegador diferente

### El instalador no se abre
- Verifica que descargaste el archivo completo
- Intenta descargar nuevamente
- Comprueba que tienes permisos de lectura

### La aplicación no inicia
- Intenta desinstalar y reinstalar
- Verifica que tienes espacio suficiente (50-80 MB)
- Reinicia tu dispositivo

### Error de permisos (Linux)
```bash
# Dar permisos de ejecución
chmod +x Animalia_Desktop_App_0.1.0_amd64.AppImage

# O instalar como paquete DEB
sudo apt install ./animalia-desktop-app_0.1.0_amd64.deb
```

---

## 📞 Soporte

Si encuentras problemas:
1. Consulta la guía de instalación: `GUIA_INSTALACION.md`
2. Lee el inicio rápido: `INICIO_RAPIDO.md`
3. Reporta bugs: https://github.com/yoqer/animalia-desktop-app/issues

---

## 📋 Resumen de Descargas

| Plataforma | Archivo | Tamaño | Tipo |
|-----------|---------|--------|------|
| Windows | Animalia_Desktop_App_0.1.0.msi | ~70 MB | MSI |
| macOS (Intel) | Animalia_Desktop_App_0.1.0_x64.dmg | ~80 MB | DMG |
| macOS (M1/M2) | Animalia_Desktop_App_0.1.0_aarch64.dmg | ~80 MB | DMG |
| Linux (AppImage) | Animalia_Desktop_App_0.1.0_amd64.AppImage | ~65 MB | AppImage |
| Linux (DEB) | animalia-desktop-app_0.1.0_amd64.deb | ~55 MB | DEB |
| Android | animalia-desktop-app-0.1.0.apk | ~60 MB | APK |
| iOS | Animalia_Desktop_App_0.1.0.ipa | ~75 MB | IPA |
| Código Fuente | animalia-desktop-app-v0.1.0-complete.zip | ~48 KB | ZIP |

¡Disfruta usando Animalia Desktop App! 🎉
