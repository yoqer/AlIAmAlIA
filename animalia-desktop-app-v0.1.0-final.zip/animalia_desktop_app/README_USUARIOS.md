# 🦁 Animalia Desktop App - Guía para Usuarios

Bienvenido a **Animalia Desktop App**, una aplicación multiplataforma para análisis de comportamiento animal, gestión de conocimiento y reentrenamiento de modelos de IA.

## 📥 Descarga e Instalación Rápida

### 1️⃣ Descargar la Aplicación

Ve a **[Releases](https://github.com/yoqer/animalia-desktop-app/releases)** y descarga el instalador para tu sistema operativo:

| Sistema Operativo | Archivo | Tamaño |
|------------------|---------|--------|
| **Windows** | `Animalia_Desktop_App_0.1.0.msi` | ~70 MB |
| **macOS (Intel)** | `Animalia_Desktop_App_0.1.0_x64.dmg` | ~80 MB |
| **macOS (M1/M2/M3)** | `Animalia_Desktop_App_0.1.0_aarch64.dmg` | ~80 MB |
| **Linux (AppImage)** | `Animalia_Desktop_App_0.1.0_amd64.AppImage` | ~65 MB |
| **Linux (Ubuntu/Debian)** | `animalia-desktop-app_0.1.0_amd64.deb` | ~55 MB |
| **Android** | `animalia-desktop-app-0.1.0.apk` | ~60 MB |
| **iOS** | `Animalia_Desktop_App_0.1.0.ipa` | ~75 MB |

### 2️⃣ Instalar

#### 🪟 Windows
1. Descarga `Animalia_Desktop_App_0.1.0.msi`
2. Haz doble clic en el archivo
3. Sigue el asistente de instalación
4. ¡Listo!

#### 🍎 macOS
1. Descarga el archivo `.dmg` correspondiente a tu Mac
2. Haz doble clic para montar la imagen
3. Arrastra Animalia a la carpeta "Aplicaciones"
4. ¡Listo!

#### 🐧 Linux (AppImage)
```bash
chmod +x Animalia_Desktop_App_0.1.0_amd64.AppImage
./Animalia_Desktop_App_0.1.0_amd64.AppImage
```

#### 🐧 Linux (Ubuntu/Debian)
```bash
sudo apt install ./animalia-desktop-app_0.1.0_amd64.deb
```

#### 🤖 Android
1. Descarga `animalia-desktop-app-0.1.0.apk`
2. Abre el archivo en tu dispositivo
3. Toca "Instalar"
4. ¡Listo!

#### 🍎 iOS
1. Descarga `Animalia_Desktop_App_0.1.0.ipa`
2. Abre con Transporter o Xcode
3. Sigue las instrucciones
4. ¡Listo!

## 🎯 Primeros Pasos

### 1. Abre la Aplicación

Busca "Animalia" en tu menú de aplicaciones y abre.

### 2. Explora las 5 Pestañas

```
┌─────────────────────────────────────┐
│  Animalia Desktop App               │
├─────────────────────────────────────┤
│                                     │
│  [Contenido de la pestaña]          │
│                                     │
├─────────────────────────────────────┤
│ 💬 Chat │ 👁️ Patrones │ 📚 Conocimiento │ ⚡ Reentreno │ ⚙️ Ajustes │
└─────────────────────────────────────┘
```

### 3. Comienza a Usar

#### 💬 Chat RAG
- Escribe preguntas sobre comportamiento animal
- La app responde basándose en el conocimiento local
- Historial guardado automáticamente

#### 👁️ Patrones
- Explora patrones de comportamiento detectados
- Filtra por categoría (Comunicación, Alimentación, etc.)
- Busca especies específicas

#### 📚 Conocimiento
- Importa datos JSON con información animal
- Agrega conocimiento manual
- Organiza por categorías

#### ⚡ Reentreno
- Solicita reentrenamiento de modelos
- Monitorea el progreso
- Descarga modelos actualizados

#### ⚙️ Ajustes
- Configura conexión a hosting web
- Habilita sincronización automática
- Conecta LLM local (opcional)

## 🔄 Sincronización con la Web

Animalia Desktop App se sincroniza automáticamente con la versión web en **torete.net/animaliav3/**

### Funcionalidades Locales (App Desktop)
- ✅ Chat RAG
- ✅ Visualización de patrones
- ✅ Gestión de conocimiento
- ✅ Solicitud de reentreno

### Funcionalidades Web (Requiere Conexión)
- ✅ Reentrenamiento avanzado
- ✅ Fine-tuning de modelos
- ✅ Análisis estadístico
- ✅ Gestión de múltiples usuarios
- ✅ Exportación de datos

## 💾 Datos y Privacidad

- **Almacenamiento Local**: Todos los datos se guardan en tu dispositivo
- **Sincronización Opcional**: Solo se sincroniza si lo activas
- **Sin Recopilación**: No recopilamos datos personales
- **Respaldo**: Puedes exportar tus datos en cualquier momento

## 🌐 Conectar a la Versión Web

1. Ve a **Ajustes**
2. En "Conexión a Hosting", ingresa: `https://torete.net/animaliav3`
3. Marca "Sincronización automática"
4. Toca "Guardar Configuración"

La app se sincronizará automáticamente cada X segundos.

## 🆘 Solución de Problemas

### La app no inicia
- Intenta desinstalar y reinstalar
- Verifica que tienes espacio suficiente (50-80 MB)
- Reinicia tu dispositivo

### No se sincroniza
- Verifica tu conexión a internet
- Comprueba la URL del hosting en Ajustes
- Intenta sincronizar manualmente

### El chat no responde
- Espera unos segundos
- Verifica tu conexión a internet
- Intenta reiniciar la app

### No puedo importar JSON
- Verifica que el archivo sea JSON válido
- Comprueba la estructura del archivo
- Intenta con un archivo de ejemplo

## 📚 Documentación Completa

- **[INICIO_RAPIDO.md](INICIO_RAPIDO.md)** - Comienza en 5 minutos
- **[GUIA_INSTALACION.md](GUIA_INSTALACION.md)** - Instalación detallada
- **[DESCARGA.md](DESCARGA.md)** - Información de descargas
- **[README.md](README.md)** - Documentación técnica

## 🎓 Tutoriales

### Tutorial 1: Crear tu Primer Chat
1. Abre la pestaña **Chat**
2. Escribe: "¿Cuál es el comportamiento de comunicación de los leones?"
3. Presiona Enter
4. La app responde basándose en el conocimiento

### Tutorial 2: Importar Datos
1. Abre la pestaña **Conocimiento**
2. Toca el botón **Importar JSON**
3. Selecciona tu archivo JSON
4. Los datos se importarán automáticamente

### Tutorial 3: Solicitar Reentreno
1. Abre la pestaña **Reentreno**
2. Toca **Nueva Solicitud**
3. Selecciona el modelo y prioridad
4. Toca **Enviar Solicitud**
5. Monitorea el progreso

## 🔧 Configuración Recomendada

### Para Uso Offline
- Desactiva sincronización automática
- Importa datos localmente
- Usa LLM local (si disponible)

### Para Uso Online
- Activa sincronización automática
- Conecta a hosting web
- Usa reentrenamiento en la web

### Para Máximo Rendimiento
- Reduce intervalo de sincronización a 300 segundos
- Limpia caché regularmente
- Exporta datos antiguos

## 📞 Obtener Ayuda

### Reportar Bugs
- Ve a [Issues](https://github.com/yoqer/animalia-desktop-app/issues)
- Describe el problema detalladamente
- Incluye tu sistema operativo y versión

### Sugerir Mejoras
- Ve a [Discussions](https://github.com/yoqer/animalia-desktop-app/discussions)
- Comparte tu idea
- Vota por ideas que te gusten

### Contacto
- Email: support@animalia.app
- Twitter: @AnimaliaApp
- Discord: [Servidor Animalia](https://discord.gg/animalia)

## 🎉 Características Principales

- 🌍 **Multiplataforma**: Windows, macOS, Linux, Android, iOS
- 📱 **Mobile-First**: Optimizado para dispositivos móviles
- 🔄 **Sincronización**: Automática con la web
- 💾 **Offline-First**: Funciona sin conexión
- 🎨 **Interfaz Intuitiva**: Fácil de usar
- 🚀 **Rápido**: Rendimiento optimizado
- 🔒 **Privado**: Tus datos son tuyos

## 📊 Estadísticas

- ⭐ **Versión**: 0.1.0
- 📦 **Tamaño**: 50-80 MB
- 🚀 **Velocidad**: Inicio < 2 segundos
- 💾 **Almacenamiento**: SQLite local
- 🌐 **Sincronización**: Automática cada 3600 segundos

## 🗺️ Hoja de Ruta

- [x] Versión 0.1.0 - Funcionalidades básicas
- [ ] Versión 0.2.0 - Mejoras de UI/UX
- [ ] Versión 0.3.0 - Análisis avanzado
- [ ] Versión 1.0.0 - Lanzamiento oficial

## 📄 Licencia

Animalia Desktop App está bajo licencia MIT. Puedes usar, modificar y distribuir libremente.

## 🙏 Agradecimientos

Gracias por usar Animalia Desktop App. Tu feedback nos ayuda a mejorar.

---

**¿Necesitas ayuda?** Consulta la [documentación completa](README.md) o [reporta un bug](https://github.com/yoqer/animalia-desktop-app/issues).

**¿Quieres contribuir?** ¡Bienvenido! Abre un [Pull Request](https://github.com/yoqer/animalia-desktop-app/pulls).

¡Disfruta usando Animalia! 🦁✨
