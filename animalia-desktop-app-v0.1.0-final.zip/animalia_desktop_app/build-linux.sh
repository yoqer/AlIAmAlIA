#!/bin/bash

# Animalia Desktop App - Linux Build Script
# Este script compila la aplicación para Linux (AppImage y .deb)

echo "╔════════════════════════════════════════════════════════════╗"
echo "║   Animalia Desktop App - Compilación para Linux           ║"
echo "╚════════════════════════════════════════════════════════════╝"

# Verificar si Node.js está instalado
echo ""
echo "[1/5] Verificando Node.js..."
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js no está instalado"
    echo "Instálalo con: sudo apt-get install nodejs npm"
    exit 1
fi
echo "✓ Node.js encontrado: $(node --version)"

# Verificar si Rust está instalado
echo ""
echo "[2/5] Verificando Rust..."
if ! command -v rustc &> /dev/null; then
    echo "ERROR: Rust no está instalado"
    echo "Descárgalo desde https://rustup.rs/"
    exit 1
fi
echo "✓ Rust encontrado: $(rustc --version)"

# Verificar dependencias del sistema
echo ""
echo "[3/5] Verificando dependencias del sistema..."
MISSING_DEPS=0

if ! command -v libssl-dev &> /dev/null; then
    echo "⚠ libssl-dev no encontrado. Instálalo con: sudo apt-get install libssl-dev"
    MISSING_DEPS=1
fi

if ! command -v pkg-config &> /dev/null; then
    echo "⚠ pkg-config no encontrado. Instálalo con: sudo apt-get install pkg-config"
    MISSING_DEPS=1
fi

if [ $MISSING_DEPS -eq 1 ]; then
    echo "Por favor, instala las dependencias faltantes y vuelve a ejecutar este script"
    exit 1
fi
echo "✓ Todas las dependencias del sistema están presentes"

# Instalar dependencias
echo ""
echo "[4/5] Instalando dependencias del proyecto..."
npm install
if [ $? -ne 0 ]; then
    echo "ERROR: Fallo al instalar dependencias"
    exit 1
fi
echo "✓ Dependencias instaladas"

# Compilar la aplicación
echo ""
echo "[5/5] Compilando aplicación..."
npm run build
if [ $? -ne 0 ]; then
    echo "ERROR: Fallo al compilar"
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║   ✓ Compilación completada exitosamente                   ║"
echo "║   Los instaladores están listos para descargar            ║"
echo "╚════════════════════════════════════════════════════════════╝"

echo ""
echo "Archivos generados:"
echo "1. AppImage: src-tauri/target/release/bundle/appimage/"
echo "2. .deb: src-tauri/target/release/bundle/deb/"
echo ""
echo "Para instalar:"
echo "• AppImage: ./Animalia_Desktop_App_*.AppImage"
echo "• .deb: sudo apt install ./animalia-desktop-app_*.deb"
