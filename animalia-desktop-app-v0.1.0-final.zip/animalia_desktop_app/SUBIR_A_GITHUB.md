# 📤 Guía: Subir Animalia a GitHub y Compilar

Esta guía te ayudará a subir el código a GitHub y usar GitHub Actions para compilar automáticamente.

## 🎯 Objetivo

Al finalizar tendrás:
- ✅ Código en GitHub
- ✅ Compilación automática para todas las plataformas
- ✅ Instaladores descargables
- ✅ Todo sin instalar Rust

## 📋 Requisitos Previos

1. **Cuenta de GitHub** (gratuita en https://github.com)
2. **Git instalado** en tu máquina
3. **Acceso al código** (ya lo tienes en `/home/ubuntu/animalia_desktop_app`)

## 🚀 Paso a Paso

### Paso 1: Crear Repositorio en GitHub

1. Ve a https://github.com/new
2. Nombre: `animalia-desktop-app`
3. Descripción: `Aplicación multiplataforma para análisis de comportamiento animal`
4. Privacidad: **Público** (necesario para GitHub Actions gratuito)
5. Haz clic en **"Create repository"**

### Paso 2: Configurar Git en tu Máquina

```bash
# Navega a la carpeta del proyecto
cd /home/ubuntu/animalia_desktop_app

# Inicializa git (si no está inicializado)
git init

# Configura tu nombre y email
git config user.name "Tu Nombre"
git config user.email "tu.email@ejemplo.com"

# Agrega el repositorio remoto (reemplaza TU_USUARIO con tu usuario de GitHub)
git remote add origin https://github.com/TU_USUARIO/animalia-desktop-app.git

# Verifica que se agregó correctamente
git remote -v
```

### Paso 3: Subir el Código a GitHub

```bash
# Agrega todos los archivos
git add .

# Crea un commit
git commit -m "Initial commit: Animalia Desktop App v0.1.0"

# Sube a GitHub (rama main)
git branch -M main
git push -u origin main
```

### Paso 4: Crear una Etiqueta de Versión

GitHub Actions se activa cuando creas una etiqueta con formato `v*`.

```bash
# Crea una etiqueta
git tag v0.1.0

# Sube la etiqueta a GitHub
git push origin v0.1.0
```

### Paso 5: Monitorear la Compilación

1. Ve a tu repositorio: `https://github.com/TU_USUARIO/animalia-desktop-app`
2. Haz clic en la pestaña **"Actions"**
3. Verás un flujo de trabajo llamado **"Build Animalia Desktop App"**
4. Espera a que se complete (30-60 minutos)

**Indicadores de progreso:**
- 🟡 Amarillo = En progreso
- 🟢 Verde = Completado
- 🔴 Rojo = Error

### Paso 6: Descargar los Instaladores

Una vez completada la compilación:

1. Ve a **"Releases"** en tu repositorio
2. Busca la versión `v0.1.0`
3. Descarga los instaladores que necesites

**Archivos disponibles:**
- Windows: `Animalia_Desktop_App_0.1.0.msi`
- macOS Intel: `Animalia_Desktop_App_0.1.0_x64.dmg`
- macOS Apple Silicon: `Animalia_Desktop_App_0.1.0_aarch64.dmg`
- Linux AppImage: `Animalia_Desktop_App_0.1.0_amd64.AppImage`
- Linux DEB: `animalia-desktop-app_0.1.0_amd64.deb`
- Android: `animalia-desktop-app-0.1.0.apk`
- iOS: `Animalia_Desktop_App_0.1.0.ipa`

## 🔄 Compilar una Nueva Versión

Para compilar una nueva versión después de hacer cambios:

```bash
# Haz cambios en el código
# (edita archivos según sea necesario)

# Agrega los cambios
git add .

# Crea un commit
git commit -m "Descripción de los cambios"

# Sube los cambios
git push

# Crea una nueva etiqueta
git tag v0.2.0

# Sube la etiqueta
git push origin v0.2.0
```

GitHub Actions compilará automáticamente la nueva versión.

## 📊 Monitorear Compilaciones

### Ver Estado en Tiempo Real

1. Ve a **Actions** en tu repositorio
2. Haz clic en el flujo de trabajo más reciente
3. Verás el progreso de cada plataforma

### Ver Logs de Compilación

Si algo falla:

1. Ve a **Actions**
2. Haz clic en el flujo de trabajo fallido
3. Haz clic en el job que falló
4. Lee los logs para ver el error

### Descargar Artefactos

Los artefactos se guardan temporalmente (30 días):

1. Ve a **Actions**
2. Haz clic en el flujo de trabajo completado
3. Desplázate hacia abajo para ver "Artifacts"
4. Descarga lo que necesites

## 🛠️ Personalizar la Compilación

### Cambiar Versión

Edita `package.json`:
```json
{
  "version": "0.2.0"
}
```

### Cambiar Nombre de la Aplicación

Edita `tauri.conf.json`:
```json
{
  "productName": "Mi Animalia App"
}
```

### Compilar Solo para Ciertas Plataformas

Edita `.github/workflows/build.yml` y comenta los jobs que no necesites:

```yaml
# build-windows:
#   runs-on: windows-latest
#   ...
```

## ❓ Preguntas Frecuentes

**P: ¿Cuánto tiempo toma compilar?**
R: 30-60 minutos en total (todas las plataformas en paralelo).

**P: ¿Cuesta dinero?**
R: No, GitHub Actions es gratuito para repositorios públicos (hasta 2000 minutos/mes).

**P: ¿Qué pasa si la compilación falla?**
R: Verás el error en los logs. Revisa el error y corrige el código.

**P: ¿Puedo compilar sin crear una etiqueta?**
R: Sí, edita `.github/workflows/build.yml` y cambia `on: push: tags:` a `on: push: branches: [main]`.

**P: ¿Los instaladores son seguros?**
R: Sí, se generan a partir de tu código en GitHub.

## 🔐 Seguridad

- Los instaladores se generan en servidores de GitHub
- Tu código fuente es público (si el repositorio es público)
- No se almacenan secretos en el repositorio
- Los instaladores se descargan directamente desde GitHub

## 📝 Ejemplo Completo

```bash
# 1. Navega a la carpeta
cd /home/ubuntu/animalia_desktop_app

# 2. Configura git
git init
git config user.name "Tu Nombre"
git config user.email "tu.email@ejemplo.com"
git remote add origin https://github.com/TU_USUARIO/animalia-desktop-app.git

# 3. Sube el código
git add .
git commit -m "Initial commit: Animalia Desktop App v0.1.0"
git branch -M main
git push -u origin main

# 4. Crea etiqueta
git tag v0.1.0
git push origin v0.1.0

# 5. Espera compilación (30-60 minutos)
# Ve a: https://github.com/TU_USUARIO/animalia-desktop-app/actions

# 6. Descarga instaladores
# Ve a: https://github.com/TU_USUARIO/animalia-desktop-app/releases
```

## 🎯 Próximos Pasos

1. ✅ Crea repositorio en GitHub
2. ✅ Sube el código
3. ✅ Crea etiqueta de versión
4. ✅ Espera compilación
5. ✅ Descarga instaladores
6. ✅ Comparte con usuarios

## 📞 Solución de Problemas

### Error: "fatal: not a git repository"
```bash
cd /home/ubuntu/animalia_desktop_app
git init
```

### Error: "Permission denied (publickey)"
- Configura SSH en GitHub: https://docs.github.com/en/authentication/connecting-to-github-with-ssh
- O usa HTTPS en lugar de SSH

### Error: "Workflow file not found"
- Asegúrate de que `.github/workflows/build.yml` existe
- Verifica que está en la rama correcta

### Los instaladores no aparecen
- Espera a que se complete la compilación
- Actualiza la página de Releases
- Verifica que creaste una etiqueta (v0.1.0, v0.2.0, etc.)

## 📚 Recursos Adicionales

- [Documentación de GitHub](https://docs.github.com)
- [Documentación de Git](https://git-scm.com/doc)
- [Documentación de GitHub Actions](https://docs.github.com/en/actions)
- [Documentación de Tauri](https://tauri.app/docs/)

¡Listo! Ahora puedes compilar Animalia Desktop App para todas las plataformas sin instalar Rust. 🎉
