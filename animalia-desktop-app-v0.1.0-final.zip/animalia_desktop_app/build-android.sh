#!/bin/bash

# Animalia Desktop App - Android Build Script
# Este script compila la aplicación para Android (APK)

echo "╔════════════════════════════════════════════════════════════╗"
echo "║   Animalia Desktop App - Compilación para Android         ║"
echo "╚════════════════════════════════════════════════════════════╝"

# Verificar si Node.js está instalado
echo ""
echo "[1/6] Verificando Node.js..."
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js no está instalado"
    exit 1
fi
echo "✓ Node.js encontrado: $(node --version)"

# Verificar si Java está instalado
echo ""
echo "[2/6] Verificando Java..."
if ! command -v java &> /dev/null; then
    echo "ERROR: Java no está instalado"
    echo "Descárgalo desde https://www.oracle.com/java/technologies/downloads/"
    exit 1
fi
echo "✓ Java encontrado: $(java -version 2>&1 | head -1)"

# Verificar si Android SDK está instalado
echo ""
echo "[3/6] Verificando Android SDK..."
if [ -z "$ANDROID_SDK_ROOT" ]; then
    echo "ERROR: ANDROID_SDK_ROOT no está configurado"
    echo "Descarga Android Studio desde https://developer.android.com/studio"
    echo "Luego configura: export ANDROID_SDK_ROOT=/ruta/a/android/sdk"
    exit 1
fi
echo "✓ Android SDK encontrado: $ANDROID_SDK_ROOT"

# Verificar si Rust está instalado
echo ""
echo "[4/6] Verificando Rust..."
if ! command -v rustc &> /dev/null; then
    echo "ERROR: Rust no está instalado"
    exit 1
fi
echo "✓ Rust encontrado: $(rustc --version)"

# Instalar targets de Rust para Android
echo ""
echo "[5/6] Configurando Rust para Android..."
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android i686-linux-android
if [ $? -ne 0 ]; then
    echo "ERROR: Fallo al configurar Rust"
    exit 1
fi
echo "✓ Targets configurados"

# Compilar la aplicación
echo ""
echo "[6/6] Compilando aplicación para Android..."
npm install
npm run build -- --target android
if [ $? -ne 0 ]; then
    echo "ERROR: Fallo al compilar"
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║   ✓ Compilación completada exitosamente                   ║"
echo "║   El APK está listo para descargar                        ║"
echo "╚════════════════════════════════════════════════════════════╝"

echo ""
echo "Pasos siguientes:"
echo "1. Busca el archivo .apk en: src-tauri/target/release/bundle/apk/"
echo "2. Transfiere el APK a tu dispositivo Android"
echo "3. Abre el archivo APK para instalar"
echo "4. Permite la instalación desde fuentes desconocidas si es necesario"
echo ""
echo "O instala directamente con adb:"
echo "adb install -r animalia-desktop-app.apk"
