# Iconos de Animalia Desktop App

Esta carpeta contiene los iconos de la aplicación para diferentes plataformas.

## Archivos Requeridos

### Windows
- `icon.ico` - Icono principal (256x256)
- `32x32.png` - Icono pequeño
- `128x128.png` - Icono mediano
- `128x128@2x.png` - Icono retina
- `installer-header.bmp` - Encabezado del instalador (150x57)
- `installer-sidebar.bmp` - Barra lateral del instalador (164x314)

### macOS
- `icon.icns` - Icono principal (múltiples tamaños)
- `dmg-background.tiff` - Fondo del DMG

### Linux
- `32x32.png` - Icono pequeño
- `128x128.png` - Icono mediano
- `256x256.png` - Icono grande
- `512x512.png` - Icono extra grande

### Android
- `icon.png` - Icono de la aplicación (192x192 mínimo)

### iOS
- `icon.png` - Icono de la aplicación (1024x1024)

## Generación de Iconos

### Opción 1: Usar una herramienta online
- https://www.favicon-generator.org/
- https://icon.kitchen/

### Opción 2: Usar ImageMagick
```bash
# Convertir PNG a ICO (Windows)
convert icon.png -define icon:auto-resize=256,128,96,64,48,32,16 icon.ico

# Convertir PNG a ICNS (macOS)
# Requiere herramientas de macOS

# Crear múltiples tamaños
convert icon.png -resize 32x32 32x32.png
convert icon.png -resize 128x128 128x128.png
convert icon.png -resize 256x256 256x256.png
convert icon.png -resize 512x512 512x512.png
```

### Opción 3: Usar Tauri CLI
```bash
npm install -D @tauri-apps/cli
npx tauri icon /ruta/a/icon.png
```

## Requisitos de Diseño

- **Formato**: PNG con fondo transparente
- **Tamaño Base**: 1024x1024 píxeles
- **Estilo**: Minimalista, moderno
- **Color**: Verde (#10b981) como color principal
- **Margen**: Dejar 10% de margen alrededor del icono

## Icono Recomendado para Animalia

El icono debe representar:
- 🦁 Un animal (león, águila, etc.)
- 🧬 Elementos de IA/Tecnología
- 🌍 Conexión/Red
- 💚 Color verde como identificador

## Estructura del Icono

```
┌─────────────────────┐
│                     │
│    [Animal Icon]    │
│    [AI Elements]    │
│                     │
└─────────────────────┘
```

## Instalación de Iconos

1. Crea o descarga tu icono en formato PNG (1024x1024)
2. Coloca el archivo `icon.png` en esta carpeta
3. Ejecuta: `npx tauri icon icon.png`
4. Los iconos se generarán automáticamente
5. Compila la aplicación: `npm run build`

## Verificación

Después de compilar, verifica que los iconos aparecen correctamente en:
- Instalador de Windows
- Paquete DMG de macOS
- Menú de aplicaciones de Linux
- Pantalla de inicio de Android
- Pantalla de inicio de iOS

## Notas

- Los iconos deben ser de alta calidad (sin pixelación)
- Usa colores que contrasten bien
- Asegúrate de que el icono sea reconocible en tamaños pequeños
- Prueba el icono en diferentes plataformas antes de compilar
