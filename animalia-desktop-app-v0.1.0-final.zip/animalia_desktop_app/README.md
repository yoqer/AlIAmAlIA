# Animalia Desktop App - V0.1.0

Aplicación multiplataforma minimalista para análisis de comportamiento animal, gestión de conocimiento y reentrenamiento de modelos de IA con Tauri.

## Características

- **Multiplataforma**: Windows, macOS, Linux (iOS/Android en futuras versiones)
- **Offline-First**: Almacenamiento local con sincronización automática
- **Chat RAG**: Interfaz de conversación contextualizada con memoria local
- **Análisis de Patrones**: Visualización de comportamiento animal con jerarquía taxonómica
- **Gestión de Conocimiento**: Importación de datos JSON/CSV para entrenamiento
- **Reentreno Local**: Soporte para GPU (CUDA/Metal) con pesos personalizados
- **Sincronización Híbrida**: Conexión con torete.net/animaliav3/ para actualizaciones
- **Configuración Flexible**: LLM local opcional y preferencias de sincronización

## Requisitos

- Node.js 18+
- Rust 1.70+ (para compilación de Tauri)
- npm o pnpm

## Instalación

```bash
# Clonar el repositorio
git clone https://github.com/yoqer/animalia-desktop-app.git
cd animalia-desktop-app

# Instalar dependencias
pnpm install

# Desarrollo
pnpm dev

# Compilación
pnpm build
```

## Estructura del Proyecto

```
src/
  components/       # Componentes reutilizables (TabBar, etc.)
  pages/           # Páginas principales (Chat, Patrones, Conocimiento, etc.)
  hooks/           # Hooks personalizados (useSyncManager)
  lib/             # Utilidades (sync.ts, animalHierarchy.ts)
  stores/          # Estado global con Zustand
  types/           # Definiciones TypeScript
  App.tsx          # Componente principal
  main.tsx         # Punto de entrada
  index.css        # Estilos globales

src-tauri/        # Código Rust de Tauri
tauri.conf.json   # Configuración de Tauri
```

## Fases de Desarrollo

- [x] Fase 1: Configuración base
- [x] Fase 2: Interfaz mobile-first
- [ ] Fase 3: Sincronización con hosting
- [ ] Fase 4: Gestión de conocimiento avanzada
- [ ] Fase 5: Visor de análisis
- [ ] Fase 6: Chat RAG mejorado
- [ ] Fase 7: Módulo de reentreno
- [ ] Fase 8: Exportación/Importación
- [ ] Fase 9: Configuración avanzada
- [ ] Fase 10: Optimización
- [ ] Fase 11: Auditoría
- [ ] Fase 12: Empaquetado

## Tecnologías

- **Frontend**: React 18, TypeScript, Tailwind CSS
- **Estado**: Zustand
- **Desktop**: Tauri 2
- **HTTP**: Axios
- **Build**: Vite
- **Iconos**: Lucide React

## Configuración

### URL de Hosting

La aplicación se sincroniza con `https://torete.net/animaliav3/`. Configura la URL en Ajustes si es necesario.

### LLM Local

Para usar un LLM local:
1. Habilita la opción en Ajustes
2. Proporciona el endpoint (ej. `http://localhost:8000`)
3. Especifica el modelo (ej. `llama2`)

### Sincronización Automática

- **Intervalo**: Configurable en Ajustes (por defecto 3600 segundos)
- **Al iniciar**: Se sincroniza automáticamente al abrir la app
- **Offline**: Funciona completamente sin conexión

## Desarrollo

### Agregar una nueva página

1. Crear archivo en `src/pages/NuevaPage.tsx`
2. Importar en `App.tsx`
3. Agregar pestaña en `TabBar.tsx`
4. Actualizar tipos en `src/types/index.ts`

### Agregar estado global

Usar Zustand en `src/stores/appStore.ts`:

```typescript
export const useAppStore = create<AppState>((set) => ({
  // estado
  newField: null,
  // acciones
  setNewField: (value) => set({ newField: value }),
}))
```

## Compilación Multiplataforma

```bash
# Windows
pnpm build --target x86_64-pc-windows-msvc

# macOS
pnpm build --target x86_64-apple-darwin

# Linux
pnpm build --target x86_64-unknown-linux-gnu
```

## Licencia

MIT

## Autor

Manus AI - Proyecto Animalia

## Soporte

Para reportar bugs o solicitar features, abre un issue en GitHub.
