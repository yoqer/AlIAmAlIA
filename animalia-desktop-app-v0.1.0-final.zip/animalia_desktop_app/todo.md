# Animalia Desktop App - Project TODO

## Fase 1: Configuración Base
- [x] Inicializar proyecto Tauri con estructura modular
- [x] Configurar Vite, TypeScript y Tailwind CSS
- [x] Establecer estructura de carpetas
- [x] Crear configuración de build multiplataforma

## Fase 2: Interfaz Mobile-First
- [x] Implementar sistema de pestañas cuadráticas
- [x] Crear navegación táctil optimizada
- [x] Diseñar layout responsive
- [x] Implementar componentes base (TabBar)
- [x] Crear tema visual minimalista

## Fase 3: Sincronización con Hosting
- [ ] Implementar cliente HTTP para torete.net/animaliav3/
- [ ] Crear sistema de sincronización automática
- [ ] Implementar gestión de errores de sincronización
- [ ] Crear indicador de estado de sincronización
- [ ] Implementar caché local de datos

## Fase 4: Gestión de Conocimiento Local
- [ ] Implementar almacenamiento SQLite
- [ ] Crear CRUD para entradas de conocimiento
- [ ] Implementar importación de JSON/CSV
- [ ] Crear búsqueda y filtrado
- [ ] Implementar exportación de datos

## Fase 5: Visor de Análisis de Comportamiento
- [ ] Implementar jerarquía taxonómica visual
- [ ] Crear visualización de patrones
- [ ] Implementar filtros por categoría
- [ ] Crear gráficos de confianza
- [ ] Implementar búsqueda de especies

## Fase 6: Chat RAG Mejorado
- [ ] Integrar LLM local opcional
- [ ] Implementar almacenamiento de conversaciones
- [ ] Crear historial persistente
- [ ] Implementar sincronización de chats
- [ ] Agregar soporte para markdown

## Fase 7: Módulo de Reentreno
- [ ] Detectar disponibilidad de GPU
- [ ] Crear interfaz de solicitud de reentreno
- [ ] Implementar carga de pesos personalizados
- [ ] Crear seguimiento de progreso
- [ ] Implementar notificaciones de completitud

## Fase 8: Exportación/Importación
- [ ] Implementar exportación a JSON
- [ ] Implementar exportación a SQLite
- [ ] Crear importación de backups
- [ ] Implementar validación de datos
- [ ] Agregar opciones de compresión

## Fase 9: Configuración Avanzada
- [ ] Crear interfaz de configuración completa
- [ ] Implementar persistencia de preferencias
- [ ] Agregar opciones de tema
- [ ] Crear gestor de conexiones
- [ ] Implementar logs de depuración

## Fase 10: Optimización
- [ ] Optimizar tamaño de bundle
- [ ] Implementar lazy loading
- [ ] Optimizar rendimiento de SQLite
- [ ] Reducir consumo de memoria
- [ ] Optimizar sincronización

## Fase 11: Auditoría y Correcciones
- [ ] Revisar código TypeScript
- [ ] Corregir errores y bugs
- [ ] Implementar manejo de errores
- [ ] Crear tests unitarios
- [ ] Documentar código

## Fase 12: Empaquetado y Distribución
- [ ] Compilar para Windows
- [ ] Compilar para macOS
- [ ] Compilar para Linux
- [ ] Crear instaladores
- [ ] Preparar para distribución

## Bugs Reportados
- (Ninguno por el momento)

## Features Solicitadas
- (Ninguno por el momento)
