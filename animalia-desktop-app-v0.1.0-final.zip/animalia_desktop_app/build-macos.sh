#!/bin/bash

# Animalia Desktop App - macOS Build Script
# Este script compila la aplicación para macOS (Intel y Apple Silicon)

echo "╔════════════════════════════════════════════════════════════╗"
echo "║   Animalia Desktop App - Compilación para macOS           ║"
echo "╚════════════════════════════════════════════════════════════╝"

# Verificar si Node.js está instalado
echo ""
echo "[1/6] Verificando Node.js..."
if ! command -v node &> /dev/null; then
    echo "ERROR: Node.js no está instalado"
    echo "Descárgalo desde https://nodejs.org/"
    exit 1
fi
echo "✓ Node.js encontrado: $(node --version)"

# Verificar si Rust está instalado
echo ""
echo "[2/6] Verificando Rust..."
if ! command -v rustc &> /dev/null; then
    echo "ERROR: Rust no está instalado"
    echo "Descárgalo desde https://rustup.rs/"
    exit 1
fi
echo "✓ Rust encontrado: $(rustc --version)"

# Detectar arquitectura
echo ""
echo "[3/6] Detectando arquitectura..."
ARCH=$(uname -m)
if [ "$ARCH" = "arm64" ]; then
    echo "✓ Arquitectura Apple Silicon (M1/M2/M3) detectada"
    TARGET="aarch64-apple-darwin"
elif [ "$ARCH" = "x86_64" ]; then
    echo "✓ Arquitectura Intel detectada"
    TARGET="x86_64-apple-darwin"
else
    echo "ERROR: Arquitectura no soportada: $ARCH"
    exit 1
fi

# Instalar target de Rust si es necesario
echo ""
echo "[4/6] Configurando Rust para $TARGET..."
rustup target add $TARGET
if [ $? -ne 0 ]; then
    echo "ERROR: Fallo al configurar Rust"
    exit 1
fi
echo "✓ Target configurado"

# Instalar dependencias
echo ""
echo "[5/6] Instalando dependencias..."
npm install
if [ $? -ne 0 ]; then
    echo "ERROR: Fallo al instalar dependencias"
    exit 1
fi
echo "✓ Dependencias instaladas"

# Compilar la aplicación
echo ""
echo "[6/6] Compilando aplicación..."
npm run build
if [ $? -ne 0 ]; then
    echo "ERROR: Fallo al compilar"
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║   ✓ Compilación completada exitosamente                   ║"
echo "║   El paquete .dmg está listo para descargar               ║"
echo "╚════════════════════════════════════════════════════════════╝"

echo ""
echo "Pasos siguientes:"
echo "1. Busca el archivo .dmg en: src-tauri/target/release/bundle/dmg/"
echo "2. Haz doble clic para montar la imagen"
echo "3. Arrastra la aplicación a la carpeta Aplicaciones"
echo "4. Ejecuta desde Aplicaciones"
