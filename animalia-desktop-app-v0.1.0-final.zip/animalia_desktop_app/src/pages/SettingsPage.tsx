import React, { useState } from 'react'
import { Save, Download, Upload } from 'lucide-react'
import { useAppStore } from '../stores/appStore'

export default function SettingsPage() {
  const { config, setConfig } = useAppStore()
  const [settings, setSettings] = useState({
    hostingUrl: config?.hostingUrl || 'https://torete.net/animaliav3',
    autoSync: config?.syncPreferences.autoSync || true,
    syncInterval: config?.syncPreferences.syncInterval || 3600,
    localLLMEnabled: config?.localLLM?.enabled || false,
    localLLMEndpoint: config?.localLLM?.endpoint || 'http://localhost:8000',
    localLLMModel: config?.localLLM?.model || 'llama2',
  })

  const handleSaveSettings = () => {
    const updatedConfig = {
      hostingUrl: settings.hostingUrl,
      userId: config?.userId || '',
      localLLM: {
        enabled: settings.localLLMEnabled,
        endpoint: settings.localLLMEndpoint,
        model: settings.localLLMModel,
      },
      syncPreferences: {
        autoSync: settings.autoSync,
        syncInterval: settings.syncInterval,
        syncOnStartup: true,
      },
      cacheSize: config?.cacheSize || 1024,
    }
    setConfig(updatedConfig)
    alert('Configuración guardada correctamente')
  }

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="p-4 border-b border-gray-200">
        <h1 className="text-lg font-semibold text-gray-900">Configuración</h1>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6 safe-pb-20">
        <section>
          <h2 className="text-base font-semibold text-gray-900 mb-3">Conexión a Hosting</h2>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                URL del Hosting
              </label>
              <input
                type="url"
                value={settings.hostingUrl}
                onChange={(e) =>
                  setSettings({ ...settings, hostingUrl: e.target.value })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-base font-semibold text-gray-900 mb-3">Sincronización</h2>
          <div className="space-y-3">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.autoSync}
                onChange={(e) =>
                  setSettings({ ...settings, autoSync: e.target.checked })
                }
                className="w-4 h-4 rounded border-gray-300 text-green-600 focus:ring-green-500"
              />
              <span className="text-sm text-gray-700">Sincronización automática</span>
            </label>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Intervalo de sincronización (segundos)
              </label>
              <input
                type="number"
                value={settings.syncInterval}
                onChange={(e) =>
                  setSettings({
                    ...settings,
                    syncInterval: parseInt(e.target.value),
                  })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              />
            </div>
          </div>
        </section>

        <section>
          <h2 className="text-base font-semibold text-gray-900 mb-3">LLM Local (Opcional)</h2>
          <div className="space-y-3">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.localLLMEnabled}
                onChange={(e) =>
                  setSettings({ ...settings, localLLMEnabled: e.target.checked })
                }
                className="w-4 h-4 rounded border-gray-300 text-green-600 focus:ring-green-500"
              />
              <span className="text-sm text-gray-700">Habilitar LLM local</span>
            </label>

            {settings.localLLMEnabled && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Endpoint
                  </label>
                  <input
                    type="url"
                    value={settings.localLLMEndpoint}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        localLLMEndpoint: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Modelo
                  </label>
                  <input
                    type="text"
                    value={settings.localLLMModel}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        localLLMModel: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </>
            )}
          </div>
        </section>

        <section>
          <h2 className="text-base font-semibold text-gray-900 mb-3">Información</h2>
          <div className="p-3 bg-gray-50 rounded-lg border border-gray-200">
            <p className="text-sm text-gray-600">
              <strong>Versión:</strong> 0.1.0
            </p>
            <p className="text-sm text-gray-600 mt-1">
              <strong>Base de datos:</strong> SQLite Local
            </p>
          </div>
        </section>
      </div>

      <div className="p-4 border-t border-gray-200 bg-white safe-pb-4">
        <button
          onClick={handleSaveSettings}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <Save size={18} />
          Guardar Configuración
        </button>
      </div>
    </div>
  )
}
