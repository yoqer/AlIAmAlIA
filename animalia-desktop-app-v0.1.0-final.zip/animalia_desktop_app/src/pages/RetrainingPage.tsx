import React, { useState } from 'react'
import { Upload, Zap } from 'lucide-react'

interface RetrainingRequest {
  id: string
  status: 'pending' | 'processing' | 'completed' | 'failed'
  priority: 'normal' | 'high' | 'urgent'
  targetModel: 'vision' | 'chat' | 'all'
  progress: number
  createdAt: Date
}

export default function RetrainingPage() {
  const [requests, setRequests] = useState<RetrainingRequest[]>([])
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    priority: 'normal' as const,
    targetModel: 'all' as const,
  })
  const [gpuAvailable] = useState(false)

  const handleSubmitRequest = () => {
    const newRequest: RetrainingRequest = {
      id: Date.now().toString(),
      status: 'pending',
      priority: formData.priority,
      targetModel: formData.targetModel,
      progress: 0,
      createdAt: new Date(),
    }

    setRequests([...requests, newRequest])
    setShowForm(false)
    setFormData({ priority: 'normal', targetModel: 'all' })
  }

  const statusColors = {
    pending: 'bg-yellow-100 text-yellow-800',
    processing: 'bg-blue-100 text-blue-800',
    completed: 'bg-green-100 text-green-800',
    failed: 'bg-red-100 text-red-800',
  }

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="p-4 border-b border-gray-200">
        <h1 className="text-lg font-semibold text-gray-900 mb-4">Solicitar Reentreno</h1>

        <div className="p-3 rounded-lg bg-gray-50 border border-gray-200 mb-4">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-gray-700">GPU Local</span>
            <span
              className={`text-sm font-semibold px-3 py-1 rounded ${
                gpuAvailable
                  ? 'bg-green-100 text-green-800'
                  : 'bg-red-100 text-red-800'
              }`}
            >
              {gpuAvailable ? 'Disponible' : 'No disponible'}
            </span>
          </div>
          <p className="text-xs text-gray-600 mt-2">
            {gpuAvailable
              ? 'Puedes entrenar modelos localmente con GPU'
              : 'El reentreno se realizará en el servidor de hosting'}
          </p>
        </div>

        <button
          onClick={() => setShowForm(!showForm)}
          className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
        >
          <Zap size={18} />
          Nueva Solicitud
        </button>
      </div>

      {showForm && (
        <div className="p-4 border-b border-gray-200 bg-gray-50">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Prioridad
              </label>
              <select
                value={formData.priority}
                onChange={(e) =>
                  setFormData({ ...formData, priority: e.target.value as any })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="normal">Normal</option>
                <option value="high">Alta</option>
                <option value="urgent">Urgente</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Modelo Objetivo
              </label>
              <select
                value={formData.targetModel}
                onChange={(e) =>
                  setFormData({ ...formData, targetModel: e.target.value as any })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
              >
                <option value="vision">Visión</option>
                <option value="chat">Chat</option>
                <option value="all">Todos</option>
              </select>
            </div>

            <div className="flex gap-2">
              <button
                onClick={handleSubmitRequest}
                className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Enviar Solicitud
              </button>
              <button
                onClick={() => setShowForm(false)}
                className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto p-4 space-y-3 safe-pb-20">
        {requests.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-500">
            <p className="text-center">No hay solicitudes de reentreno</p>
          </div>
        ) : (
          requests.map((request) => (
            <div
              key={request.id}
              className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-gray-900">
                    Modelo: {request.targetModel}
                  </h3>
                  <p className="text-sm text-gray-600">
                    Prioridad: {request.priority}
                  </p>
                </div>
                <span
                  className={`text-xs font-semibold px-3 py-1 rounded ${
                    statusColors[request.status]
                  }`}
                >
                  {request.status}
                </span>
              </div>

              <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                <div
                  className="bg-green-600 h-2 rounded-full transition-all"
                  style={{ width: `${request.progress}%` }}
                ></div>
              </div>

              <p className="text-xs text-gray-500">
                {request.createdAt.toLocaleString()}
              </p>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
