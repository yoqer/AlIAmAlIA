import { create } from 'zustand'
import type { User, AppConfig, SyncStatus, Conversation, BehaviorPattern } from '../types'

interface AppState {
  user: User | null
  config: AppConfig | null
  syncStatus: SyncStatus
  conversations: Conversation[]
  patterns: BehaviorPattern[]
  selectedTab: 'chat' | 'patterns' | 'knowledge' | 'retraining' | 'settings'

  setUser: (user: User | null) => void
  setConfig: (config: AppConfig) => void
  setSyncStatus: (status: SyncStatus) => void
  setConversations: (conversations: Conversation[]) => void
  setPatterns: (patterns: BehaviorPattern[]) => void
  setSelectedTab: (tab: AppState['selectedTab']) => void
  addConversation: (conversation: Conversation) => void
  removeConversation: (id: string) => void
  addPattern: (pattern: BehaviorPattern) => void
  updateSyncStatus: (partial: Partial<SyncStatus>) => void
}

export const useAppStore = create<AppState>((set) => ({
  user: null,
  config: null,
  syncStatus: {
    lastSync: null,
    isSyncing: false,
    pendingChanges: 0,
    syncErrors: [],
  },
  conversations: [],
  patterns: [],
  selectedTab: 'chat',

  setUser: (user) => set({ user }),
  setConfig: (config) => set({ config }),
  setSyncStatus: (status) => set({ syncStatus: status }),
  setConversations: (conversations) => set({ conversations }),
  setPatterns: (patterns) => set({ patterns }),
  setSelectedTab: (selectedTab) => set({ selectedTab }),

  addConversation: (conversation) =>
    set((state) => ({
      conversations: [...state.conversations, conversation],
    })),

  removeConversation: (id) =>
    set((state) => ({
      conversations: state.conversations.filter((c) => c.id !== id),
    })),

  addPattern: (pattern) =>
    set((state) => ({
      patterns: [...state.patterns, pattern],
    })),

  updateSyncStatus: (partial) =>
    set((state) => ({
      syncStatus: { ...state.syncStatus, ...partial },
    })),
}))
