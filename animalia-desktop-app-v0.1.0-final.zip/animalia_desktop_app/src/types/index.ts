export interface User {
  id: string
  name: string
  email?: string
  createdAt: Date
}

export interface AnimalSpecies {
  id: string
  scientificName: string
  commonName: string
  kingdom: string
  phylum: string
  class: string
  order: string
  family: string
  genus: string
  species: string
}

export interface BehaviorPattern {
  id: string
  speciesId: string
  patternName: string
  description: string
  category: 'communication' | 'feeding' | 'social' | 'defense' | 'reproduction' | 'other'
  confidence: number
  detectedAt: Date
  tags: string[]
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
  conversationId: string
}

export interface Conversation {
  id: string
  title: string
  createdAt: Date
  updatedAt: Date
  messages: ChatMessage[]
  isLocal: boolean
}

export interface KnowledgeEntry {
  id: string
  type: 'behavior' | 'communication' | 'training_data'
  title: string
  content: string
  speciesId?: string
  source: 'manual' | 'imported' | 'synced'
  createdAt: Date
  tags: string[]
}

export interface RetrainingRequest {
  id: string
  status: 'pending' | 'processing' | 'completed' | 'failed'
  priority: 'normal' | 'high' | 'urgent'
  targetModel: 'vision' | 'chat' | 'all'
  dataIncluded: string[]
  createdAt: Date
  completedAt?: Date
  progress: number
  gpuAvailable: boolean
}

export interface SyncStatus {
  lastSync: Date | null
  isSyncing: boolean
  pendingChanges: number
  syncErrors: string[]
}

export interface AppConfig {
  hostingUrl: string
  userId: string
  localLLM?: {
    enabled: boolean
    endpoint: string
    model: string
  }
  syncPreferences: {
    autoSync: boolean
    syncInterval: number
    syncOnStartup: boolean
  }
  cacheSize: number
}
