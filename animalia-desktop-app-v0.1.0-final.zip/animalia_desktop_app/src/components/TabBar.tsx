import React from 'react'
import { MessageCircle, Eye, BookOpen, Zap, Settings } from 'lucide-react'
import { useAppStore } from '../stores/appStore'

type TabType = 'chat' | 'patterns' | 'knowledge' | 'retraining' | 'settings'

interface TabItem {
  id: TabType
  label: string
  icon: React.ReactNode
}

const tabs: TabItem[] = [
  { id: 'chat', label: 'Chat', icon: <MessageCircle size={24} /> },
  { id: 'patterns', label: 'Patrones', icon: <Eye size={24} /> },
  { id: 'knowledge', label: 'Conocimiento', icon: <BookOpen size={24} /> },
  { id: 'retraining', label: 'Reentreno', icon: <Zap size={24} /> },
  { id: 'settings', label: 'Ajustes', icon: <Settings size={24} /> },
]

export default function TabBar() {
  const { selectedTab, setSelectedTab } = useAppStore()

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center safe-pb-4">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => setSelectedTab(tab.id)}
          className={`flex flex-col items-center justify-center w-1/5 py-3 px-2 transition-all ${
            selectedTab === tab.id
              ? 'text-green-600 bg-green-50'
              : 'text-gray-600 hover:text-gray-900'
          }`}
          aria-label={tab.label}
        >
          <div className="mb-1">{tab.icon}</div>
          <span className="text-xs font-medium truncate">{tab.label}</span>
        </button>
      ))}
    </div>
  )
}
